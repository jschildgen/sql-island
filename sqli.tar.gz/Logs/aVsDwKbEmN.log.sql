delete from inhabitants where name= 'Dirty Dieter'
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
select * from  inhabitant



-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
SELECT * FROM inhabitant WHERE job = 'butcher'
-- There you are! Enjoy your meal! But take care of yourself. As long as you are unarmed, stay away from villains. Not everyone on this island is friendly.
delete  from  inhabitant where name = 'Dirty Dieter'



select * from  inhabitant where name = 'Dirty Dieter'



