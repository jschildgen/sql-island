-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT FROM 3
SELECT*FROM 3
SELECT
3
SELECT dorfnr1

SELECT dorfnr

SELECT name
FROM Affenstadt

SELECT name
FROM 1

SELECT dorfnr
FROM 1

SELECT 
FROM dorf

select * from Bewohner


-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
select * from Bewohner where status = friedlich


select * from Bewohner where status = "friedlich"


-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
select * from Bewohner where beruf and status = "Waffenschmidt" and "friedlich"


select * from Bewohner where beruf = "Waffenschmidt" and status = "friedlich"


select * from Bewohner where beruf = "schmiet" and status = "friedlich"


select * from Bewohner where beruf = "schmied" and status = "friedlich"


select * from Bewohner where beruf = "Waffenschmied" and status = "friedlich"


-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
select * from Bewohner where status = "friedlich" and beruf LIKE beruf = "%schmied"


select * from Bewohner where status = "friedlich" and beruf "LIKE" beruf = "%schmied"


select * from Bewohner where status = "friedlich" and beruf "LIKE %schmied"


select * from Bewohner where status = "friedlich" and beruf LIKE "%schmied"


-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
insert into bewohner (name, dorfnr, geschlecht, beruf, gold, status) values ("Maarten", 1, "m", "Schmied", 10000000000, "friedlich")


insert into bewohner (name, dorfnr, geschlecht, beruf, gold, status) values ("Maarten", 0, "m", "Schmied", 100000, "friedlich")


insert into bewohner (name, dorfnr, geschlecht, beruf, gold, status) values ("Maarten", 0, "m", "Schmied", 0, "friedlich")


insert into bewohner (name, dorfnr, geschlecht, beruf, gold, status) values ("Maarten", "0", "m", "Schmied", "0", "friedlich")


selcet * from "Fremder"


selcet * from Bewohner = "Fremder"

selcet Bewohner = "Fremder"

select * from Bewohner = "Fremder"

select * from Bewohner "Fremder"

select * from bewohnernr

select * from "bewohnernr"


select * from dorf "bewohnernr"


select * from Bewohner "bewohnernr"


select bewohnernr from Bewohner WHERE name = "Fremder"


-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
select gold from Bewohner WHERE name = "Fremder"


-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
select gegenstand WHERE besitzer = "is null"


select gegenstand from dorf WHERE besitzer = "is null"


select gegenstand from dorf WHERE besitzer IS NULL


select GEGENSTAND from dorf WHERE besitzer IS NULL


select GEGENSTAND from DORF WHERE besitzer IS NULL


select * from Gegenstand WHERE besitzer IS NULL


-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = 'Kaffeetasse'
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = "Kaffeetasse, Eimer, Teekanne, Ring, Pappkarton, Gluehbirne"
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = "Kaffeetasse", "Eimer", "Teekanne", "Ring", "Pappkarton", "Gluehbirne"
UPDATE gegenstand SET besitzer = 20 WHERE besitzer IS NULL
-- Jawoll! Welche Gegenstände besitze ich nun?
-- Jawoll! Welche Gegenstände besitze ich nun?
UPDATE gegenstand SET besitzer IS 20
UPDATE gegenstand SET besitzer 20
select * from gegenstand besitzer = 20
select * from gegenstand WHERE besitzer IS 20
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
select * from Bewohner where status = "friedlich" and beruf LIKE "%Haendler"
select * from Bewohner where status = "friedlich" and beruf LIKE "%Haendler"
select * from Bewohner where status = "friedlich" and beruf LIKE "%Haendler" or "%Kaufmann"
select * from Bewohner where status = "friedlich" and beruf LIKE "%Haendler" or "Kaufmann"
select * from Bewohner where status = "friedlich" and beruf LIKE "%Haendler" or "%Kaufmann"
select * from Bewohner where status = "friedlich" and beruf LIKE "%Haendler" or beruf LIKE "%Kaufmann"
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
select * from Bewohner IS 20 gegenstand = "Ring" and gegenstand = "Teekanne"
update gegenstand set 15 gegenstand = "Ring" and "Teekanne"
update gegenstand set 15 gegenstand = "Ring" or "Teekanne"
