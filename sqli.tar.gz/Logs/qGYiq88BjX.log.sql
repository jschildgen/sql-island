-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT-FROM Affenstadt
SELECT- Affenstadt
SELECT-Affensdadt INSERT-Bewohner
SELECT-Affensdadt SELECT-Gurkendorf SELECT- Zwiebelhausen

SELECT*FROM Bewohner


SELECT*FROM Affenstadt


SELECT*FROM Affenstadt


SELECT*FROM Affenstadt


SELECT*FROM Affenstadt


SELECT*FROM Affenstadt


SELECT*FROM Affenstadt


SELECT*FROM Affenstadt


SELECT*FROM Affenstadt


SELECT*FROM bewohner

SELECT*FROM bewohner

SELECT*FROM bewohner

SELECT*FROM bewohner

SELECT*FROM bewohner

SELECT*FROM bewohner

SELECT*FROM Bewohner

SELECT*FROM Bewohner

SELECT*FROM Bewohner

SELECT*FROM Bewohner

SELECT*FROM Bewohner

SELECT * FROM Bewohner

-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
