-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT * FROM bewohner


-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT * FROM bewohner where status ='friedlich'


-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
SELECT * FROM bewohner where status ='friedlich' and Beruf = 'Waffenschmied'



-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
SELECT * FROM bewohner where status ='friedlich' and Beruf like = %schmied



SELECT * FROM bewohner where status ='friedlich' and Beruf like  %schmied



SELECT * FROM bewohner where status ='friedlich' and Beruf like  '%schmied'



-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
SELECT ,dorfnr, FROM bewohner  



Insert into Bewohner dorfnr




Insert into Bewohner (dorfnr)





INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')





INSERT INTO bewohner (bewohnernr)




INSERT INTO bewohner (bewohnernr)VALUES ('Fremder', 1, '?', '?', 0, '?')







INSERT INTO bewohner (bewohnernr)VALUES ('Fremder',1 )







INSERT INTO bewohner (bewohnernr)VALUES ('Fremder')







INSERT INTO bewohner (bewohnernr) VALUES ('Fremder')







INSERT INTO bewohner (bewohnernr) VALUES (,Fremder,)







INSERT INTO bewohner (bewohnernr) VALUES (Fremder)







INSERT INTO bewohner ('bewohnernr') VALUES ('Fremder')







select ,bewohnernr, from Dorf 







select 'bewohnernr' from Dorf 







select 'Bewohnernr' from Dorf 







INSERT INTO bewohner ('bewohnernr') Values ('fremder')







-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
select 'bewohnernr' from dorf
select 'bewohnernr' from dorf where = 'fremder'
select 'bewohnernr' from dorf where = 'fremder'
select 'bewohnernr' from dorf where  'fremder'
select 'bewohnernr' from dorf where 'Fremder'
select 'bewohnernr' from dorf where ,Fremder,
select 'bewohnernr' from dorf where 'Fremder'
select 'bewohnernr' from 'dorf' where 'Fremder'
select 'bewohnernr' from 'dorf' where 'fremder'
select 'dorf' from 'bewohnernr' where 'fremder'
select 'dorf' from 'bewohner' where 'fremder'
