-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
select * from inhabitant
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
SELECT * FROM inhabitant WHERE job = 'butcher'
SELECT * FROM inhabitant WHERE job = 'butcher'
SELECT * FROM inhabitant WHERE job = 'butcher'
SELECT * FROM inhabitant WHERE job = 'butcher'
select * from inhabitant where job = 'butcher'
select name from inhabitant where job = 'butcher'
select name, job from inhabitant where job = 'butcher'
select name, pernoid, job from inhabitant where job = 'butcher'
select * from inhabitant where job = 'butcher'
select * from inhabitant where job = 'butcher'
