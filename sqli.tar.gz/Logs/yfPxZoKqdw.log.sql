-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select bewohnernr
SELECT bewohnernr
SELECT bewohner
SELECT haeuptling13
SELECT haeuptling
SELECT BEWOHNER(bewohnernr)
SELECT BEWOHNER
SELECT BEWOHNER(Affenstadt,Gurkendorf,Zwiebelhausen)
SELECT BEWOHNER(affenstadt, gurkendorf, zwiebelhausen)
SELECT*FROM dorf BEWOHNER
SELECT*FROM Bewohner
SELECT * FROM Bewohner
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT * FROM Bewohner WHERE status = friedlich
SELECT * FROM Bewohner WHERE status = "friedlich"
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
SELECT * FROM Bewohner WHERE status = "friedlich"
SELECT * FROM Bewohner WHERE status = "friedlich" AND beruf = "Schmied" 
SELECT * FROM Bewohner WHERE status = "friedlich" AND beruf = "Waffenschmied" 
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
SELECT * FROM Bewohner LIKE "%schmied" 
SELECT * FROM Bewohner LIKE "schmied" 
SELECT * FROM Bewohner LIKE beruf = "%schmied" 
SELECT * FROM Bewohner LIKE = "%schmied" 
SELECT * FROM Bewohner LIKE beruf = "%schmied" 
SELECT * FROM Bewohner LIKE "%schmied" 
SELECT * FROM Bewohner LIKE "%schmied" 
SELECT * FROM Bewohner LIKE = "%schmied" 
SELECT * FROM Bewohner beruf LIKE "%schmied" 
SELECT * FROM Bewohner beruf = LIKE "%schmied" 
SELECT * FROM Bewohner beruf = LIKE "%schmied" 
SELECT * FROM Bewohner beruf = LIKE "%schmied" 
SELECT * FROM Bewohner beruf = LIKE "%schmied" 
SELECT * FROM Bewohner beruf = LIKE "%schmied" 
SELECT * FROM Bewohner beruf = LIKE "%schmied" 
SELECT * FROM Bewohner beruf = LIKE "%schmied" 
SELECT * FROM Bewohner beruf = LIKE "%schmied" 
SELECT * FROM Bewohner beruf = LIKE "%schmied" 
SELECT * FROM Bewohner beruf = LIKE "%schmied" 
SELECT * FROM Bewohner beruf = "%schmied" 
SELECT * FROM Bewohner beruf "%schmied" 
SELECT * FROM Bewohner beruf LIKE ="%schmied" 
SELECT * FROM Bewohner beruf LIKE = "%schmied" 
SELECT * FROM Bewohner beruf LIKE  "%schmied" 
SELECT * FROM Bewohner beruf LIKE "%schmied" 
SELECT * FROM Bewohner Where beruf LIKE "%schmied" 
SELECT * FROM Bewohner Where beruf LIKE "%schmied" and status = "friedlich"
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
SELECT bewohnernr from name = "fremder"
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')

INSERT

INSERT INTO bewohner (bame, dorfnr,geschlecht, beruf, gold, status) VALUES ("Fremder", 69, m, Geschäftsmann, 1, boese) 

INSERT INTO bewohner (name, dorfnr,geschlecht, beruf, gold, status) VALUES ("Fremder", 69, m, Geschäftsmann, 1, boese) 

INSERT INTO bewohner (name, dorfnr,geschlecht, beruf, gold, status) VALUES ("Fremder", 69,m, Geschäftsmann, 1, boese) 

INSERT INTO bewohner (name, dorfnr,geschlecht, beruf, gold, status) VALUES ("Fremder", 69, w, Geschäftsmann, 1, boese) 

INSERT INTO bewohner (name, dorfnr,, beruf, gold, status) VALUES ("Fremder", 69, Geschäftsmann, 1, boese) 

INSERT INTO bewohner (name, dorfnr, beruf, gold, status) VALUES ("Fremder", 69, Geschäftsmann, 1, boese) 

INSERT INTO bewohner (name, dorfnr,geschlecht, beruf, gold, status) VALUES ("Fremder", 69,"m", "Geschäftsmann", 1, "boese") 

INSERT INTO bewohner (name, dorfnr,geschlecht, beruf, gold, status) VALUES ("Fremder", 69,"m", "Geschäftsmann", 100, "boese") 

INSERT INTO bewohner (name, dorfnr,geschlecht, beruf, gold, status) VALUES ("Fremder", 2,"m", "Geschäftsmann", 100, "boese") 

INSERT INTO bewohner (name, dorfnr,geschlecht, beruf, gold, status) VALUES ("Klaus", 2,"m", "Geschäftsmann", 100, "boese") 

SELCT From bewohner (name, dorfnr, geschlecht, beruf, gold, status)
SELCT From bewohner (name, dorfnr, geschlecht, beruf, gold, status)
SELECT From bewohner (name, dorfnr, geschlecht, beruf, gold, status)
SELECT from bewohner (name, dorfnr, geschlecht, beruf, gold, status)
SELECT from "fremder" (name, dorfnr, geschlecht, beruf, gold, status)
SELECT "fremder" (name, dorfnr, geschlecht, beruf, gold, status)
SELECT "fremder" (name, dorfnr, geschlecht, beruf, gold, status)
SELECT "fremder" dorfnr
SELECT "fremder" (dorfnr)
SELECT "fremder" dorfnr
SELECT "1" dorfnr
 "1" dorfnr
 INSERT INTO "fremder" dorfnr
SELECT dorfnr from name = "fremder"
SELECT dorfnr from name = "fremder" AND "TOm"
