-- Ó céus, o que aconteceu? Parece que eu sou o único sobrevivente do acidente aéreo. Nossa, existem algumas aldeias nessa ilha.
SELECT * FROM aldeia
-- Parece que existem algumas pessoas vivendo nessas aldeias. Como posso ver uma lista de todos os habitantes?
select * from habitante;
-- Cara! Estou com muita fome. Vou procurar um açougueiro e pedir algumas salsichas grátis.
select * from habitante
-- Aqui está! Aproveite a refeição! Mas tome cuidado! Enquanto estiver desarmado, fique longe dos vilões. Nem todo mundo nessa ilha é amigável.
select * from habitante where idpessoa = 20
