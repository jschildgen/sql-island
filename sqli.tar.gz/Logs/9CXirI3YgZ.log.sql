-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
select * from inhabitant
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
SELECT * FROM inhabitant WHERE job = 'butcher'
-- There you are! Enjoy your meal! But take care of yourself. As long as you are unarmed, stay away from villains. Not everyone on this island is friendly.
select * from inhabitant where state = 'friendly'
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
select * from inhabitant where state = 'friendly' and job = 'blacksmith'
select * from inhabitant where state = 'friendly' and job = 'blacksmith'
select * from inhabitant where job = 'blacksmith' and state = 'friendly'
select * from inhabitant where job = 'weaponsmith' and state = 'friendly'
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
select * from inhabitant where job LIKE '%smith' and state = 'friendly'
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
INSERT INTO inhabitant (name, villageid, gender, job, gold, state) VALUES ('Stranger', 1, '?', '?', 0, '?')
-- No need to call me stranger! What's my personid? (Hint: In former queries, the * stands for: all columns. Instead of the star, you can also address one or more columns (seperated by a comma) and you will only get the columns you need.)
insert into inhabitant (Lucas, 4, m, merchant, 999, friendly)
insert into inhabitant ('Lucas', 4, m, merchant, 999, friendly)
insert into inhabitant (name, villageid, gender, job, gold, state) values ('Lucas', 4, m, merchant, 999, friendly)
insert into inhabitant (name, villageid, gender, job, gold, state) values ('Lucas', 1, m, merchant, 999, friendly)
insert into inhabitant ('Lucas', 1, m, merchant, 999, friendly)
