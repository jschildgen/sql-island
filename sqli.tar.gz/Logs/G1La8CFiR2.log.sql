-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
SELECT * FROM inhabitant
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
SELECT * FROM inhabitant WHERE job = 'butcher'
-- There you are! Enjoy your meal! But take care of yourself. As long as you are unarmed, stay away from villains. Not everyone on this island is friendly.
SELECT * FROM inhabitant
SELECT * FROM inhabitant where state = 'friendly'
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
SELECT * FROM inhabitant where job = 'weaponsmith' and state = 'friendly'
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
SELECT * FROM inhabitant where job like '%smith' and state = 'friendly'
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
INSERT INTO inhabitant (name, villageid, gender, job, gold, state) VALUES ('Stranger', 1, '?', '?', 0, '?')
-- No need to call me stranger! What's my personid? (Hint: In former queries, the * stands for: all columns. Instead of the star, you can also address one or more columns (seperated by a comma) and you will only get the columns you need.)
SELECT personid FROM inhabitant where job like '%smith' and state = 'friendly'
SELECT personid FROM inhabitant where name = 'Stranger'
-- Hi Ernest! How much is a sword?
-- Hi Ernest! How much is a sword?
SELECT gold FROM inhabitant where name = 'Stranger'
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
SELECT gold FROM inhabitant where name = 'Stranger'

SELECT * FROM item where owner is null
SELECT gold FROM inhabitant where name = 'Stranger'

SELECT item FROM ITEM where owner is null
SELECT item FROM ITEM where owner is null
SELECT * FROM ITEM where owner is null
-- Yay, a coffee cup. Let's collect it!
-- Yay, a coffee cup. Let's collect it!
UPDATE item SET owner = 20 WHERE item = 'coffee cup'
-- Do you know a trick how to collect all the ownerless items?
UPDATE item SET owner = 20 WHERE owner is NULL
-- Now list all of the items I have!
-- Now list all of the items I have!
SELECT * FROM item where owner = 20
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
SELECT * FROM inhabitant where state = 'Friendly' AND (job = 'merchant' or job = 'dealer')
SELECT * FROM inhabitant where state = 'friendly' AND (job = 'merchant' or job = 'dealer')
-- I'd like to get the ring and the teapot. The rest is nothing but scrap. Please give me the two items. My personid is 15.
-- I'd like to get the ring and the teapot. The rest is nothing but scrap. Please give me the two items. My personid is 15.
UPDATE item SET OWNER = 15 WHERE item = 'ring' or item = 'teapot'
-- Here, some gold!
-- Here, some gold!
UPDATE inhabitant SET gold = gold + 120 WHERE personid = 20
-- Unfortunately, that's not enough gold to buy a sword. Seems like I do have to work after all. Maybe it's not a bad idea to change my name from Stranger to my real name before I will apply for a job.
UPDATE INHAbITANT set name = 'Bob' where personid = 20
-- Since baking is one of my hobbies, why not find a baker who I can work for? (Hint: List all bakers and use 'ORDER BY gold' to sort the results. 'ORDER BY gold DESC' is even better because then the richest baker is on top.)
-- Since baking is one of my hobbies, why not find a baker who I can work for? (Hint: List all bakers and use 'ORDER BY gold' to sort the results. 'ORDER BY gold DESC' is even better because then the richest baker is on top.)
