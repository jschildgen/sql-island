SELECT bewohner.name FROM BEWOHNER, dorfnr WHERE dorf.dorfnr = bewohner.dorfnr AND bewohner.dorf = 'Zwiebelhausen'
