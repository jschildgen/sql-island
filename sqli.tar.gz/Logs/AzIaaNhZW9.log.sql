-- Ó céus, o que aconteceu? Parece que eu sou o único sobrevivente do acidente aéreo. Nossa, existem algumas aldeias nessa ilha.
SELECT * FROM aldeia
-- Parece que existem algumas pessoas vivendo nessas aldeias. Como posso ver uma lista de todos os habitantes?
select*from habitante
SELECT*from habitante
SELECT*FROM habitante
SELECT * FROM habitante
-- Cara! Estou com muita fome. Vou procurar um açougueiro e pedir algumas salsichas grátis.
-- Cara! Estou com muita fome. Vou procurar um açougueiro e pedir algumas salsichas grátis.
SELECT * FROM habitante WHERE trabalho = 'açougueiro'
-- Aqui está! Aproveite a refeição! Mas tome cuidado! Enquanto estiver desarmado, fique longe dos vilões. Nem todo mundo nessa ilha é amigável.
SELECT * FROM habitante WHERE status='amigável'
-- "Não tem jeito de conseguir uma espada por conta própria. Vou tentar encontrar algum ferreiro amigável para forjar uma espada para mim (""armamento-ferreiro""). (Dica: Você pode combinar predicados na cláusula WHERE usando o AND.)"
-- "Não tem jeito de conseguir uma espada por conta própria. Vou tentar encontrar algum ferreiro amigável para forjar uma espada para mim (""armamento-ferreiro""). (Dica: Você pode combinar predicados na cláusula WHERE usando o AND.)"
SELECT * FROM habitante WHERE status='amigável'AND trabalho='armamento-ferreiro
SELECT * FROM habitante WHERE status='amigável'AND trabalho='armamento-ferreiro'
-- "Isso não parece nada bom. Talvez outro aldeão amigável com perícia em ferraria possa ajudá-lo, por exemplo qualquer ferreiro. Tente: use LIKE ""%ferreiro"" para encontrar os habitantes cujo trabalho termine com ""ferreiro"" (% é um coringa para qualquer número de caracteres). "
-- "Isso não parece nada bom. Talvez outro aldeão amigável com perícia em ferraria possa ajudá-lo, por exemplo qualquer ferreiro. Tente: use LIKE ""%ferreiro"" para encontrar os habitantes cujo trabalho termine com ""ferreiro"" (% é um coringa para qualquer número de caracteres). "
SELECT * FROM habitante WHERE status='amigável'AND trabalho LIKE='%ferreiro'
SELECT * FROM habitante WHERE status='amigável'AND trabalho LIKE'%ferreiro'
-- Olá estranho! Aonde está indo? Eu sou Paul, o prefeito da Cidade Macaco. Irei registrá-lo como cidadão.
-- Olá estranho! Aonde está indo? Eu sou Paul, o prefeito da Cidade Macaco. Irei registrá-lo como cidadão.
INSERT INTO habitante (nome, idaldeia, gênero, trabalho, ouro, status) VALUES ('Estranho', 1, '?', '?', 0, '?')
-- Não precisa me chamar de estranho! Qual é meu idpessoa? (Dica: Em consultas formais, o * significa todas as colunas. Ao invés de utilizá-lo, você pode endereçar uma ou mais colunas, separadas por vírgula, e você obterá somente as colunas que precisar!)
SELECT nome,idaldeia FROM habitante WHERE idaldeia = 1
SELECT nome,idaldeia FROM habitante 
SELECT nome,idpessoa FROM habitante 
SELECT nome,idpessoa FROM habitante WHERE idpessoa = 1
SELECT idpessoa FROM habitante WHERE idpessoa = 1
SELECT idpessoa,nome FROM habitante WHERE idpessoa = 1
SELECT nome FROM habitante
SELECT nome,idpessoa FROM habitante
SELECT nome,idpessoa FROM habitante WHERE idpessoa=20
SELECT idpessoa,nome,idaldeia,gênero,trabalho,ouro,status FROM habitante 
SELECT idpessoa FROM habitante 
SELECT idpessoa,nome FROM habitante 
SELECT idpessoa FROM habitante WHERE nome='Estranho'
-- Olá Ernesto! Quanto custa uma espada?
-- Olá Ernesto! Quanto custa uma espada?
SELECT ouro FROM habitante WHERE nome='Estranho'
-- Nossa, o olho da cara! Deve haver outra opção para ganhar ouro além de ter que trabalhar. Talvez eu possa coletar itens sem dono e vendê-los. Posso fazer uma lista de itens que não pertencem a ninguém? (Dica: você pode identificar itens sem dono com: WHERE proprietario IS NULL)
-- Nossa, o olho da cara! Deve haver outra opção para ganhar ouro além de ter que trabalhar. Talvez eu possa coletar itens sem dono e vendê-los. Posso fazer uma lista de itens que não pertencem a ninguém? (Dica: você pode identificar itens sem dono com: WHERE proprietario IS NULL)
SELECT item FROM item WHERE proprietário = null
SELECT item FROM item WHERE proprietário is null
SELECT item FROM item WHERE proprietario is null
SELECT item,proprietário FROM item WHERE proprietário is null
-- Eba, uma xícara! Vamos coletá-la!
-- Eba, uma xícara! Vamos coletá-la!
UPDATE item SET proprietário = 20 WHERE item = 'xícara'
-- Você sabe um truque para coletar todos os itens sem dono?
UPDATE item SET proprietário=20 WHERE proprietário is null
-- Agora liste todos os itens que eu tenho!
-- Agora liste todos os itens que eu tenho!
SELECT item,proprietário FROM item WHERE proprietário=20 
-- Encontre um habitante amigável que seja ou negociante ou mercador. Talvez ele queira comprar algum dos meus itens. (Dica: Quando utilizar tanto AND quanto OR , não esqueça de inserir corretamente os parênteses.)
-- Encontre um habitante amigável que seja ou negociante ou mercador. Talvez ele queira comprar algum dos meus itens. (Dica: Quando utilizar tanto AND quanto OR , não esqueça de inserir corretamente os parênteses.)
SELECT idpessoa,nome,trabalho FROM habitante WHERE trabalho='negociante' or 'mercador' 
SELECT idpessoa,nome,trabalho FROM habitante WHERE trabalho=('negociante') or ('mercador') 
SELECT idpessoa,nome,trabalho FROM habitante WHERE trabalho=('negociante')OR('mercador') 
SELECT idpessoa,nome,trabalho FROM habitante WHERE trabalho='negociante'OR trabalho='mercador'
SELECT idpessoa,nome,trabalho FROM habitante WHERE trabalho=('negociante')OR trabalho=('mercador')
SELECT idpessoa,nome FROM habitante WHERE trabalho=('negociante')OR trabalho=('mercador')
SELECT idpessoa,nome FROM habitante WHERE status='amigável' AND trabalho=('negociante')OR trabalho=('mercador')
SELECT idpessoa,nome FROM habitante WHERE status=('amigável') AND trabalho=('negociante')OR trabalho=('mercador')
SELECT idpessoa,nome,trabalho FROM habitante WHERE status=('amigável') AND trabalho=('negociante')OR trabalho=('mercador')
SELECT idpessoa,nome,trabalho FROM habitante WHERE (status='amigável' )AND trabalho='negociante'OR trabalho='mercador'
SELECT idpessoa,nome,trabalho FROM habitante WHERE (status='amigável' )AND (trabalho='negociante'OR trabalho='mercador')
SELECT idpessoa,nome,trabalho FROM habitante WHERE status='amigável' AND (trabalho='negociante'OR trabalho='mercador')
SELECT idpessoa,nome,trabalho FROM habitante WHERE (trabalho='negociante' OR trabalho='mercador') AND status='amigável'
SELECT nome FROM habitante WHERE (trabalho='negociante' OR trabalho='mercador') AND status='amigável'
SELECT nome FROM habitante WHERE (status = 'amigável') AND trabalho='negociante' OR trabalho='mercador'
SELECT nome FROM habitante WHERE (status = 'amigável') AND (trabalho='negociante' OR trabalho='mercador')
SELECT idpessoa FROM habitante WHERE (status = 'amigável') AND (trabalho='negociante' OR trabalho='mercador')
SELECT idpessoa,nome FROM habitante WHERE (status = 'amigável') AND (trabalho='negociante' OR trabalho='mercador')
SELECT idpessoa,nome FROM habitante WHERE (status = 'amigável' AND (trabalho='negociante' OR trabalho='mercador'))
SELECT idpessoa,nome FROM habitante WHERE (status = 'amigável' AND (trabalho='negociante' OR 'mercador'))
SELECT idpessoa,nome FROM habitante WHERE (status = 'amigável') AND (trabalho='negociante' OR 'mercador')
SELECT idpessoa,nome FROM habitante WHERE (status = 'amigável') AND (trabalho='negociante') OR (trabalho='mercador')
SELECT idpessoa,nome FROM habitante WHERE (status = 'amigável') AND (trabalho='negociante' OR trabalho='mercador')
SELECT idpessoa,nome,trbalho,status FROM habitante WHERE (status = 'amigável') AND (trabalho='negociante' OR trabalho='mercador')
SELECT idpessoa,nome,trabalho,status FROM habitante WHERE (status = 'amigável') AND (trabalho='negociante' OR trabalho='mercador')
SELECT nome,trabalho,status FROM habitante WHERE (status = 'amigável') AND (trabalho='negociante' OR trabalho='mercador')
SELECT nome,trabalho,status FROM habitante WHERE (status = 'amigável') AND trabalho='negociante' OR trabalho='mercador'
SELECT idpessoa,nome,trabalho,status FROM habitante WHERE (status = 'amigável') AND trabalho='negociante' OR trabalho='mercador'
SELECT idpessoa,nome,trabalho,status FROM habitante WHERE trabalho='negociante' OR trabalho='mercador'AND(status = 'amigável') 
SELECT idpessoa,nome,trabalho,status FROM habitante WHERE (trabalho='negociante' OR trabalho='mercador')AND(status='amigável') 
SELECT idpessoa,nome,trabalho,status FROM habitante WHERE trabalho='negociante' OR trabalho='mercador'AND(status='amigável') 
SELECT * FROM habitante WHERE trabalho=('negociante' OR trabalho='mercador')AND(status='amigável') 
SELECT nome FROM habitante WHERE(status='amigável')AND trabalho='negociante' OR trabalho='mercador'
SELECT nome FROM habitante WHERE(status='amigável')AND (trabalho='negociante' OR trabalho='mercador')
SELECT nome,trabalho,status FROM habitante WHERE(status='amigável')AND (trabalho='negociante' OR trabalho='mercador')
SELECT nome,trabalho,status FROM habitante WHERE(status='amigável')AND (trabalho='negociante') OR (trabalho='mercador')
SELECT * FROM habitante WHERE(status='amigável')AND (trabalho='negociante') OR (trabalho='mercador')
-- Eu gostaria da xícara e do anel. O resto não é nada além de sucata. Por favor me dê esses dois itens. Meu idpessoa é 15.
-- Eu gostaria da xícara e do anel. O resto não é nada além de sucata. Por favor me dê esses dois itens. Meu idpessoa é 15.
UPDATE item SET proprietário=15 WHERE item='xícara' and item='anel'

UPDATE item SET proprietário=15 WHERE (item='xícara') and (item='anel')

UPDATE item SET proprietário=15 WHERE item IN ('xícara','anel')

UPDATE item SET proprietário=15 WHERE item='xícara'

UPDATE item SET proprietário=15 WHERE (item='xícara'AND item= 'anel')

UPDATE item SET proprietário=15 WHERE item='xícara'AND item='anel'

UPDATE item SET proprietário=15 WHERE (item='xícara'AND proprietário=20) AND (item='anel'AND proprietário=20)

UPDATE item SET proprietário=15 WHERE (item='xícara'AND proprietário=20

UPDATE item SET proprietário=15 WHERE item='xícara'AND proprietário=20

UPDATE item SET proprietário=15 WHERE (item='xícara')AND proprietário=20

UPDATE item SET proprietário=15 WHERE (item='xícara')AND (proprietário=20)

UPDATE item SET proprietário=15 WHERE proprietário=20 AND item='xícara'
UPDATE item SET proprietário=15 WHERE item='xícara'
UPDATE item SET proprietário=15 WHERE item='xícara' AND item='anel'
SELECT item,proprietário FROM item
