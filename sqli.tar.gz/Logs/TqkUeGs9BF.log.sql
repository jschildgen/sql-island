-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT*From dorf
SELECT * From dorf
SELECT * From dorf haeuptling
SELECT * From dorf haeuptling
SELECT * From dorf haeuptling
SELECT * From dorf haeuptling
SELECT * From dorf haeuptling
SELECT haeuptling
SELECT * From Bewohner
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT * From Bewohner status

SELECT * From Bewohner where Status = "friedlich"

-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
SELECT * From Bewohner where Status = "friedlich" and beruf = "Waffenschmied"

-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
SELECT * From Bewohner where Status = "friedlich" and beruf = "%schmied"

SELECT * From Bewohner where Status = "friedlich" and beruf = "%schmied%"

SELECT * From Bewohner where Status = "friedlich" and beruf = %"schmied"

SELECT * From Bewohner where Status = "friedlich" and beruf = "?schmied"

SELECT * From Bewohner where Status = "friedlich" and beruf = "%schmied"

SELECT * From Bewohner where Status = "friedlich" and beruf like "%schmied"

-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
SELECT bewohnernr From Bewohner 

SELECT bewohnernr From Bewohner where name = "Fremder"

-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
SELECT gold From Bewohner where name = "Fremder"

-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
SELECT * From Gegenstand where besitzer = null

SELECT * From Gegenstand where besitzer = "null"

SELECT * From Gegenstand where besitzer = ""

SELECT * From Gegenstand where besitzer == null

SELECT gegenstand From Gegenstand where besitzer = null

SELECT gegenstand From Gegenstand where besitzer = ""

SELECT gegenstand From Gegenstand

SELECT gegenstand From Gegenstand where besitzer is null

SELECT * From Gegenstand where besitzer is null

-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = 'Kaffeetasse'
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
Update gegenstand Set besitzer = 20 where besitzer from gegenstand is null

Update gegenstand Set besitzer = 20 where besitzer is null

-- Jawoll! Welche Gegenstände besitze ich nun?
-- Jawoll! Welche Gegenstände besitze ich nun?
Select * From Gegenstand 
Select * From Gegenstand where besitzer = 20
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
Select * From Bewohner where beruf = "Haendler" or "Kaufmann"
Select * From Bewohner where beruf = "Haendler" or "Kaufmann" and status = "friedlich"
Select * From Bewohner where beruf = "Haendler" or "Kaufmann" and where status = "friedlich"
Select * From Bewohner where (beruf = "Haendler" or "Kaufmann") and status = "friedlich"
Select * From Bewohner where (beruf = "Haendler" or beruf = "Kaufmann") and status = "friedlich"
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
Update Teekanne, Ring set besitzer = 15
Update gegenstand set besitzer = 15 where gegenstand = "Ring" and gegenstand = "Teekanne"
Update gegenstand set besitzer = 15 where gegenstand = "Ring"
Update gegenstand set besitzer = 15 where gegenstand = "Ring" and "Teekanne"
Update gegenstand set besitzer = 15 where gegenstand = "Ring" or gegenstand = "Teekanne"
-- Hier hast du einen Haufen Gold!
-- Hier hast du einen Haufen Gold!
UPDATE bewohner SET gold = gold + 120 WHERE bewohnernr = 20
-- Leider reicht das noch nicht für ein Schwert. Dann muss ich wohl doch arbeiten. Bevor ich mich jedoch irgendwo bewerbe, sollte ich vielleicht meinen Namen von Fremder auf meinen richtigen Namen ändern, ansonsten wird mich niemand einstellen.
Update Bewohner set name = "Christoph Seebacher"
-- In meiner Freizeit backe ich gerne. Ich glaube, ich verdiene mir ein bisschen Geld als Bäcker. Zeige mir alle Bäcker. Tipp: Mit ORDER BY gold kannst du die Liste sortieren, mit ORDER BY gold DESC steht sogar der reichste Bäcker oben.
-- In meiner Freizeit backe ich gerne. Ich glaube, ich verdiene mir ein bisschen Geld als Bäcker. Zeige mir alle Bäcker. Tipp: Mit ORDER BY gold kannst du die Liste sortieren, mit ORDER BY gold DESC steht sogar der reichste Bäcker oben.
Select * From Bewohner where beruf = "Baecker"
-- Hi, da bist du ja wieder! Soso, Christoph Seebacher heißt du also. Und du willst als Bäcker arbeiten? Da sag ich nicht nein. Ich zahle dir pro hundert Brötchen, die du mir bäckst, 1 Gold.
-- Hi, da bist du ja wieder! Soso, Christoph Seebacher heißt du also. Und du willst als Bäcker arbeiten? Da sag ich nicht nein. Ich zahle dir pro hundert Brötchen, die du mir bäckst, 1 Gold.
UPDATE bewohner SET gold = gold + 100 - 150 WHERE bewohnernr = 20
-- Hier ist dein neues Schwert, Chrostoph Soobochor! Nun kannst du überall hin!
INSERT INTO gegenstand (gegenstand, besitzer) VALUES ('Schwert', 20)
-- Gibt es auf der Insel einen Piloten? Er könnte mich nach Hause fliegen.
Select * From Bewohner where beruf = "Pilot"
-- Es ist schrecklich! Dirty Dieter hält den Piloten gefangen! Ich verrate dir einen Trick, wie wir schnell herausfinden können, in welchem Dorf Dirty Dieter wohnt.
-- Es ist schrecklich! Dirty Dieter hält den Piloten gefangen! Ich verrate dir einen Trick, wie wir schnell herausfinden können, in welchem Dorf Dirty Dieter wohnt.
SELECT dorf.name FROM dorf, bewohner WHERE dorf.dorfnr = bewohner.dorfnr AND bewohner.name = 'Dirty Dieter'
-- Auf diese Weise kannst du das Dorf mit der Dorf-Nummer suchen, die bei Dirty Dieter im Feld dorfnr steht. Ein solch genialer Ausdruck nennt sich Verbund oder Join.
Select Zwiebelhausen from dorf where 3 = 13
Select haeuptling from dorf where zwiebelhausen = 13
Select Zwiebelhausen from dorf where 3 = bewohner.3 and bewohnernr = 13
Select Zwiebelhausen from dorf where 3 = 3 and bewohnernr = 13
Select Zwiebelhausen from dorf where dorfnr = 3 and Bewohnernr = 13
Select Zwiebelhausen from Bewohner where dorfnr = 3 and Bewohnernr = 13
Select Bewohner from Zwiebelhausen where dorfnr = 3 and Bewohnernr = 13
Select * from Zwiebelhausen where dorfnr = 3 and Bewohnernr = 13
Select name from Bewohner where dorfnr = 3 and Bewohnernr = 13
-- Hm, wie viele Einwohner hat eigentlich Zwiebelhausen?
-- Hm, wie viele Einwohner hat eigentlich Zwiebelhausen?
SELECT COUNT(*) FROM bewohner, dorf WHERE dorf.dorfnr = bewohner.dorfnr AND dorf.name = 'Zwiebelhausen'
-- Hallo Christoph Seebacher, Dirty Dieter hält den Piloten im Haus seiner Schwester gefangen. Soll ich dir verraten, wie viele Frauen es in Zwiebelhausen gibt? Ach was, das kannst du schon selbst herausfinden! (Hinweis: Frauen erkennt man an geschlecht = 'w')
Select Count(*) From Bewohner where dorfnr = 3 and geschlecht = "w"
-- Ha, nur eine Frau. Mal schauen, wie sie heißt.
-- Ha, nur eine Frau. Mal schauen, wie sie heißt.
Select name From Bewohner where dorfnr = 3 and geschlecht = "w"
-- Christoph Seebacher, gib mir alles Gold, was die Bewohner von unserem Nachbardorf Gurkendorf zusammen besitzen und ich lasse den Piloten frei! Du willst wissen, wie viel das ist? Ich zeige es dir!
-- Christoph Seebacher, gib mir alles Gold, was die Bewohner von unserem Nachbardorf Gurkendorf zusammen besitzen und ich lasse den Piloten frei! Du willst wissen, wie viel das ist? Ich zeige es dir!
SELECT SUM(bewohner.gold) FROM bewohner, dorf WHERE dorf.dorfnr = bewohner.dorfnr AND dorf.name = 'Gurkendorf'
-- So viel Gold werde ich niemals allein durch Brötchenbacken verdienen können. Ich muss mir etwas anderes einfallen lassen. Wenn ich Gegenstände verkaufe und zusätzlich noch als Bäcker arbeite, kann ich maximal so viel Gold bekommen, wie die Händler, Kaufmänner und Bäcker zusammen besitzen. Wie viel ist das?
Select Sum(Gold) from bewohner where dorfnr = 3 and beruf = "Kaufmann" and beruf = "Haendler" and beruf = "Baecker"
Select Sum(Gold) from bewohner where dorfnr = 3 and beruf = "Kaufmann" or beruf = "Haendler" or beruf = "Baecker"
Select Sum(Gold) from bewohner where beruf = "Kaufmann" or beruf = "Haendler" or beruf = "Baecker"
-- Schauen wir mal die gesamten sowie durchschnittlichen Goldvorräte der einzelnen Berufe an.
-- Schauen wir mal die gesamten sowie durchschnittlichen Goldvorräte der einzelnen Berufe an.
SELECT beruf, SUM(bewohner.gold), AVG(bewohner.gold) FROM bewohner GROUP BY beruf ORDER BY AVG(bewohner.gold)
-- Interessant, die Metzger haben also das meiste Gold. Warum auch immer... Wie viel Gold haben im Durchschnitt die einzelnen Bewohnergruppen je nach Status (friedlich, böse, gefangen)?
Select status, AVG(status) from bewohner
Select status, AVG(status) from bewohner group by status

Select status, AVG(gold) from bewohner group by status

-- Dann kann ich auch gleich Dirty Dieter mit dem Schwert töten und den Piloten befreien.
-- Dann kann ich auch gleich Dirty Dieter mit dem Schwert töten und den Piloten befreien.
DELETE FROM bewohner WHERE name = 'Dirty Dieter'
-- Heeeey! Jetzt bin ich aber sauer! Was tust du wohl als nächstes, Christoph Seebacher?
Delete From bewohner Where name = "Christoph Seebacher"

-- Yeah! Jetzt muss ich nur noch den Piloten befreien.
-- Yeah! Jetzt muss ich nur noch den Piloten befreien.
Update Bewohner set status = "friedlich" where beruf = "Pilot"

Update Bewohner set status = "friedlich" where name = "Christoph Seebacher"

Update Bewohner set status = "frei" where name = "Christoph Seebacher"

Update Bewohner set status = "frei" where beruf = "Pilot"

Update Bewohner set status = "frei" where dorfnr = 2 and beruf = "Pilot"

Update Bewohner set status = "friedlich" where dorfnr = 2 and beruf = "Pilot"

Update Bewohner set status = "friedlich" where dorfnr = 2 and beruf = "Pilot" and bewohnernr = 8

Update Bewohner set status = "friedlich" where dorfnr = 2 and beruf = "Pilot" and bewohnernr = 8

