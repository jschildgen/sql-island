SELECT*FROMdorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT*FROMdorfWHEREAffenstadt
