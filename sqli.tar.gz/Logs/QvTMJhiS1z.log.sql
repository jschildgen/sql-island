-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
SELECT*from village

SELECT*personid from inhabitant

SELECT*chief from village

SELECT * chief from village

SELECT * "chief" from "village"

SELECT * From village


SELECT * From chief



SELECT "chief" From Village



SELECT "name" From Village



SELECT * inhabitant




SELECT * From Inhabitant





-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
SELECT * FROM inhabitant WHERE job = 'butcher'
-- There you are! Enjoy your meal! But take care of yourself. As long as you are unarmed, stay away from villains. Not everyone on this island is friendly.
SELECT * From Inhabitant WHERE state = "friendly"






-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
SELECT * From Inhabitant WHERE state = "friendly" and job = "weaponsmith"






-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
SELECT * From Inhabitant WHERE state = "friendly" and job = "%smith"






SELECT * From Inhabitant WHERE state = "friendly" and job = %"smith"






SELECT * From Inhabitant WHERE state = "friendly" and job = "%""smith"






SELECT * From Inhabitant WHERE state = "friendly" and job = "%smith"






SELECT * From Inhabitant WHERE state = "friendly" and job LIKE = "%smith"






SELECT * From Inhabitant WHERE state = "friendly" and job LIKE = "smith"






SELECT * From Inhabitant WHERE state = "friendly" and job LIKE = %"smith"






SELECT * From Inhabitant WHERE state = "friendly" and job LIKE = "%""smith"






SELECT * From Inhabitant WHERE state = "friendly" and job LIKE "%smith"






-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
INSERT INTO inhabitant (name, villageid, gender, job, gold, state) VALUES ('Stranger', 1, '?', '?', 0, '?')
-- No need to call me stranger! What's my personid? (Hint: In former queries, the * stands for: all columns. Instead of the star, you can also address one or more columns (seperated by a comma) and you will only get the columns you need.)
SELECT personid From Inhabitant 






SELECT personid From Inhabitant Where name = "stranger"






SELECT personid,name From Inhabitant Where name = "stranger"






SELECT personid,name From Inhabitant Where name = "Stranger"






SELECT personid From Inhabitant Where name = "Stranger"






-- Hi Ernest! How much is a sword?
-- Hi Ernest! How much is a sword?
SELECT gold From Inhabitant Where name = "Stranger"






-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
SELECT item From ITEM Where owner = "NULL"






SELECT item From ITEM Where owner = NULL






SELECT * From ITEM Where owner = "NULL"






SELECT * From ITEM Where owner = NULL






SELECT * From ITEM Where owner NULL






SELECT * From ITEM Where owner iS NULL






-- Yay, a coffee cup. Let's collect it!
-- Yay, a coffee cup. Let's collect it!
UPDATE item SET owner = 20 WHERE item = 'coffee cup'
-- Do you know a trick how to collect all the ownerless items?
UPDATE item SET owner = 20 WHERE owner is NULL





-- Now list all of the items I have!
-- Now list all of the items I have!
SELECT item From ITEM Where owner = "20"


SELECT * From ITEM Where owner = "20"


-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
SELECT * From INHABITANT where job = "dealer" OR "merchant" AND state = "friendly"


SELECT * From INHABITANT where (job = "dealer" OR "merchant") AND (state = "friendly")


SELECT * From INHABITANT where ((job = "dealer" OR "merchant") AND (state = "friendly"))



SELECT * From INHABITANT where ((job "dealer" OR "merchant") AND (state = "friendly"))



