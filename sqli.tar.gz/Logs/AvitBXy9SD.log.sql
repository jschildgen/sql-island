-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
select * from inhabitant

-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
SELECT * FROM inhabitant WHERE job = 'butcher'
-- There you are! Enjoy your meal! But take care of yourself. As long as you are unarmed, stay away from villains. Not everyone on this island is friendly.
select * from inhabitant
where state = 'friendly'
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
select * from inhabitant
where job = 'weaponsmith' and state = 'friendly'
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
select * from inhabitant
where job like '%smith' and state = 'friendly'
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
INSERT INTO inhabitant (name, villageid, gender, job, gold, state) VALUES ('Stranger', 1, '?', '?', 0, '?')
-- No need to call me stranger! What's my personid? (Hint: In former queries, the * stands for: all columns. Instead of the star, you can also address one or more columns (seperated by a comma) and you will only get the columns you need.)
select personid from inhabitant
where name = 'stranger'
select personid from inhabitant

select personid from inhabitant
where name = 'Stranger'

-- Hi Ernest! How much is a sword?
-- Hi Ernest! How much is a sword?
select gold from inhabitant
where name = 'Stranger'

-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
select item from item
where owner = null

select * from item
where owner = null

select * from item

select * from item
where owner is null
-- Yay, a coffee cup. Let's collect it!
-- Yay, a coffee cup. Let's collect it!
UPDATE item SET owner = 20 WHERE item = 'coffee cup'
-- Do you know a trick how to collect all the ownerless items?
select * from item

UPDATE item 
SET owner = 20 
WHERE item is null
select * from item

UPDATE item 
SET owner = 20 
WHERE owner is null
-- Now list all of the items I have!
-- Now list all of the items I have!
select * from item
select item from item
where owner = 20
select * from item
where owner = 20
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
select * from inhabitant
where owner = 'dealer' or 'merchant' and 'friendly'
select * from inhabitant
where job = 'dealer' or job 'merchant' and state ='friendly'
select * from inhabitant
where job = 'dealer' or job = 'merchant' and state ='friendly'
select * from inhabitant
where (job = 'dealer' or job = 'merchant') and state ='friendly'
-- I'd like to get the ring and the teapot. The rest is nothing but scrap. Please give me the two items. My personid is 15.
-- I'd like to get the ring and the teapot. The rest is nothing but scrap. Please give me the two items. My personid is 15.
update item 
set owner = 15
where item = 'teapot' and item = 'ring'
select * from item

update item 
set owner = 15
where item = 'teapot' or item = 'ring'
-- Here, some gold!
-- Here, some gold!
UPDATE inhabitant SET gold = gold + 120 WHERE personid = 20
-- Unfortunately, that's not enough gold to buy a sword. Seems like I do have to work after all. Maybe it's not a bad idea to change my name from Stranger to my real name before I will apply for a job.
update item 
set owner = 15
where item = 'teapot' or item = 'ring'
update inhabitant 
set name = 'Lukas'
where personid = 20
-- Since baking is one of my hobbies, why not find a baker who I can work for? (Hint: List all bakers and use 'ORDER BY gold' to sort the results. 'ORDER BY gold DESC' is even better because then the richest baker is on top.)
-- Since baking is one of my hobbies, why not find a baker who I can work for? (Hint: List all bakers and use 'ORDER BY gold' to sort the results. 'ORDER BY gold DESC' is even better because then the richest baker is on top.)
select job from inhabitant
where job = 'baker'
order by gold desc
select name from inhabitant
where job = 'baker'
order by gold desc
select * from inhabitant
where job = 'baker'
order by gold desc
-- Hi, you again! So, Lukas is your name. I saw you want to work as a baker? Okay! You will be paid 1 gold for 100 bread rolls.
-- Hi, you again! So, Lukas is your name. I saw you want to work as a baker? Okay! You will be paid 1 gold for 100 bread rolls.
UPDATE inhabitant SET gold = gold + 100 - 150 WHERE personid = 20
-- Here's your new sword, Lokos! Now you can go everywhere.
INSERT INTO item (item, owner) VALUES ('sword', 20)
-- Is there a pilot on this island by any chance? He could fly me home.
select * from inhabitant
where job = 'pilot'
-- Horrible, the pilot is held captive by Dirty Dieter! I will show you a trick how to find out the name of the village where Dirty Dieter lives.
-- Horrible, the pilot is held captive by Dirty Dieter! I will show you a trick how to find out the name of the village where Dirty Dieter lives.
SELECT village.name FROM village, inhabitant WHERE village.villageid = inhabitant.villageid AND inhabitant.name = 'Dirty Dieter'
-- The expression presented here is called a join. It combines the information of the inhabitant table with information of the village table by matching villageid values.
SELECT inhabitant.name
from inhabitant
inner join village on inhabitant.personid = village.chief
SELECT inhabitant.name
from inhabitant
where village.name = 'Onionville'
inner join village on inhabitant.personid = village.chief
SELECT inhabitant.name
from inhabitant, village
where inhabitant.personid = village.chief and village.name ='onionville'
SELECT inhabitant.name
from inhabitant, village
where inhabitant.personid = village.chief 
SELECT inhabitant.name
from inhabitant, village
where inhabitant.personid = village.chief AND village.name = 'Onionville'
-- Um, how many inhabitants does Onionville have?
-- Um, how many inhabitants does Onionville have?
SELECT COUNT(*) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Onionville'
-- Hello Lukas, the pilot is held captive by Dirty Dieter in his sister's house. Shall I tell you how many women there are in Onionville? Nah, you can figure it out by yourself! (Hint: Women show up as gender = 'f')
SELECT COUNT(*) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Onionville' and gender = 'f'
-- Oh, only one woman. What's her name?
-- Oh, only one woman. What's her name?
SELECT name FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Onionville' and gender = 'f'
SELECT * FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Onionville' and gender = 'f'
SELECT inhabitant.name FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Onionville' and gender = 'f'
-- Lukas, if you hand me over the entire property of our nearby village Cucumbertown, I will release the pilot. I will show you now what this property consists of.
-- Lukas, if you hand me over the entire property of our nearby village Cucumbertown, I will release the pilot. I will show you now what this property consists of.
SELECT SUM(inhabitant.gold) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Cucumbertown'
-- Oh no, baking bread alone can't solve my problems. If I continue working and selling items though, I could earn more gold than the worth of gold inventories of all bakers, dealers and merchants together. How much gold is that?
SELECT SUM(gold) FROM inhabitant 
WHERE job = 'baker' or job = 'merchant' or job = 'dealer'
-- Let's have a look at how much average gold people own, depending on their job.
-- Let's have a look at how much average gold people own, depending on their job.
SELECT job, SUM(inhabitant.gold), AVG(inhabitant.gold) FROM inhabitant GROUP BY job ORDER BY AVG(inhabitant.gold)
-- Very interesting: For some reason, butchers own the most gold. How much gold do different inhabitants have on average, depending on their state (friendly, ...)?
SELECT state, SUM(inhabitant.gold), AVG(inhabitant.gold) FROM inhabitant GROUP BY state ORDER BY AVG(inhabitant.gold)
SELECT state, AVG(inhabitant.gold) FROM inhabitant GROUP BY state ORDER BY AVG(inhabitant.gold)
-- Or I might as well go ahead and just kill Dirty Dieter with my sword!
-- Or I might as well go ahead and just kill Dirty Dieter with my sword!
DELETE FROM inhabitant WHERE name = 'Dirty Dieter'
-- Heeeey! Now I'm very angry! What will you do next, Lukas?
DELETE FROM inhabitant WHERE name = 'Dirty Diane'

-- Yeah! Now I release the pilot!
-- Yeah! Now I release the pilot!
update inhabitant
set state = friendly
where name = 'Arthur Tailor'

update inhabitant
set state = 'friendly'
where name = 'Arthur Tailor'

-- Thank's for releasing me, Lukas! I will fly you home!
-- Thank's for releasing me, Lukas! I will fly you home!
UPDATE inhabitant SET state = 'emigrated' WHERE personid = 20
