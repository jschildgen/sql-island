-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
Select * From Bewohner
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
Select * From Bewohner Where Status = "friedlich"
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
Select * From Bewohner Where Status = "friedlich" and Beruf 
=" Waffenschmied"
Select * From Bewohner Where Status = "friedlich" and Beruf 
="Waffenschmied"
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
Select * From Bewohner Where Status = "friedlich" and Beruf like 
="%schmied"
Select * From Bewohner Where Status = "friedlich" and Beruf like ="%schmied"
Select * From Bewohner Where Status = "friedlich" and Beruf like ='%schmied'
Select * From Bewohner Where Status = "friedlich" and Beruf like =%'schmied'
Select * From Bewohner Where Status = "friedlich" and Beruf Like = "%schmied"
Select * From Bewohner Where Status = "friedlich" and Beruf ="%schmied"
Select * From Bewohner Where Status = "friedlich" and Beruf ='%schmied'
Select * From Bewohner Where Status = "friedlich" and Beruf  like ='%schmied'
Select * From Bewohner Where Status = "friedlich" and Beruflike  ='%schmied'
Select * From Bewohner Where Status = "friedlich" and Beruf like ='%schmied'
Select * From Bewohner Where Status = "friedlich" and beruf like ='%schmied'
Select * From Bewohner Where Status = "friedlich" and beruf Like ='%schmied'
Select * From Bewohner Where Status = "friedlich" and beruf LIKE ='%schmied'
Select * From Bewohner Where Status = "friedlich" and beruf ='%schmied'
Select * From Bewohner Where Status = "friedlich" and beruf ='%Schmied'
Select * From Bewohner Where Status = "friedlich" and beruf = like '%schmied'
Select * From Bewohner Where Status = "friedlich" and beruf ='%schmied'
Select * From Bewohner Where Status = "friedlich" and beruf like '%schmied'
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?') 
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?') 
Insert Into bewohner (Renato, 1, m, Schüler, 999, friedlch) VALUES ('Fremder', 1, '?', '?', 0, '?') 
Insert Into bewohner (Renato, 1, m, Schüler, 999, friedlch) VALUES ('Fremder')
Insert Into bewohner (Renato, "1", m, Schüler, 999, friedlch) VALUES ('Fremder')
Insert Into bewohner (Renato, "1", m, Schüler, "999", friedlch) VALUES ('Fremder')
Insert Into bewohner (name, dorfnr, geschecht, beruf, gold, status) VALUES ('Fremder')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?','0', '?')
Insert Into bewohner (name = Renato, dorfnr = '1', geschlecht = m, beruf = schüler, gold = '999', status = friedlich) VALUES ('Fremder', 1, '?', '?','0', '?')
Insert Into bewohner (name = Renato, dorfnr = '1', geschlecht = m, beruf = schüler, gold '999', status = friedlich) VALUES ('Fremder', 1, '?', '?','0', '?')
Insert Into bewohner (name = Renato, dorfnr '1', geschlecht = m, beruf = schüler, gold '999', status = friedlich) VALUES ('Fremder', 1, '?', '?','0', '?')
Insert Into bewohner (name  Renato, dorfnr '1', geschlecht  m, beruf  schüler, gold '999', status  friedlich) VALUES ('Fremder', 1, '?', '?','0', '?')
Insert Into bewohner (name  'Renato', dorfnr '1', geschlecht  'm', beruf  'schüler', gold '999', status  'friedlich') VALUES ('Fremder', 1, '?', '?','0', '?')
Insert Into bewohner (name  'Renato', dorfnr '1', geschlecht  'm', beruf  'schüler', gold '999', status  'friedlich') VALUES ('Fremder', 1, '?', '?','0', '?')
Insert Into bewohner (name  'Renato', dorfnr '1', geschlecht  'm', beruf  'schüler', gold '999', status  'friedlich') VALUES ('Fremder', 1, '?', '?','0', '?')
Insert Into bewohner (name  "Renato", dorfnr '1', geschlecht  'm', beruf  'schüler', gold '999', status  'friedlich') VALUES ('Fremder', 1, '?', '?','0', '?')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?','0', '?')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Renato', '1', 'm', 'schüler','999', 'friedlich')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Renato', '1', 'm', 'schüler','0', 'friedlich')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder1', '1', 'm', 'schüler','0', 'friedlich')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder1', '1', 'm', '?','0', 'friedlich')
Insert Into bewohner (name, dorfnr) VALUES ('Fremder1', '1')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder1', '1', 'm', '?','0', 'friedlich')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder1', '3', 'm', '?','99', 'friedlich')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder1', '3', '?', '?','99', '?')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder1', '1', '?', '?','0', '?')
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder1', '1', '?', '?','0', '?')
Danke
Insert Into bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder1', '1', '?', '?','0', '?') 
