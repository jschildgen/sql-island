-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
DORF(1,Affenstadt,1)
select*From Bewohner

Select * From Bewohner

-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
Select * From Bewohner Where beruf= Metzger 

Select * From Bewohner Where beruf= `Metzger`

Select * From Bewohner Where beruf=Metzger

Select * From bewohner Where beruf=Metzger

Select * From bewohner Where status = `friedlich`

Select * From bewohner Where status = 'friedlich'


-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
Select * From bewohner Where status = 'friedlich'


Select * From bewohner Where beruf = waffenschmied and status = 'friedlich'


Select * From bewohner Where beruf = 'waffenschmied' and status = 'friedlich'


Select * From bewohner Where beruf = 'Waffenschmied' and status = 'friedlich'


-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
Select * From bewohner Where beruf LIKE  '%schmied' and status = 'friedlich'


-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
INSERT INTO bewohner (Ernst Peng, 3, m, Waffenschmied, 280, friedlich) VALUES ('Fremder', 1,'?','?','?','0','?'

INSERT INTO bewohner (Ernst Peng, 3, m, Waffenschmied, 280, friedlich) VALUES ('Fremder', 1,'?','?','?','0','?')

SELECT*bewohnernr where Bewohner from name

SELECT*from bewohner where name = fremder

SELECT*from bewohner where name = 'fremder'

SELECT from bewohner where name = 'fremder'

SELECT bewohner from bewohner where name = 'fremder'

SELECT bewohner from bewohner where name ='fremder'

SELECT bewohnernr from bewohner where name ='fremder'

SELECT bewohnernr from Bewohner where name ='Fremder'

-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
Select Besitzer from Bewohner where Besitzer IS NULL
Select Besitzer from Bewohner where = besitzer IS NULL
Select Besitzer from Bewohner where "=" besitzer IS NULL
Select 'Besitzer from' 'Bewohner' where = 'besitzer' IS NULL
Select GEGENSTAND from GOLD where = besitzer  IS NULL
Select 'GEGENSTAND' from 'GOLD' where = besitzer  IS NULL
Select 'GEGENSTAND' from 'GOLD' where  besitzer  IS NULL
Select 'GEGENSTAND' from 'GOLD' where  Besitzer  IS NULL
Select 'GEGENSTAND' from 'GOLD' where = Besitzer  IS NULL
Select 'GEGENSTAND' from 'GOLD' where '=' Besitzer  IS NULL
Select 'GEGENSTAND' from 'GOLD' where = Gegenstand  IS NULL
Select 'GEGENSTAND' from 'GOLD' where = 'Gegenstand'  IS NULL
Select 'Gold' from 'Bewohner' where = Gegenstand  IS NULL
Select Gold from Bewohner where = Gegenstand  IS NULL
Select Gold from Bewohnernr where = Gegenstand  IS NULL
Select Gold from 'Bewohnernr' where = Gegenstand  IS NULL
Select Gold' from 'Bewohnernr' where = Gegenstand  
Select Gold from Bewohnernr where = Gegenstand, Besitzer
Select Gold from Bewohnernr 20  where = Gegenstand, Besitzer
Select Gold from Bewohnernr '20'  where = Gegenstand, Besitzer
Select Gold from Bewohnernr '20'  where = Gegenstand, Gold
Select Gold from Gegenstand  where = Gegenstand, Gold
Select Gold from Gegenstand  where = Besitzer IS NULL
Select Gold from Bewohner  where = Besitzer IS NULL
Select * from gegenstand  where Besitzer IS null
Select * from Gegenstand  where Besitzer IS null
Select * from  Besitzer where Gold IS null
Select golf from  Bewohner where name = 'Fremder'
Select gold from  Bewohner where name = 'Fremder'
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
Select gold from  Bewohner where Besitzer IS NULL
Select Gold from  Bewohner where Besitzer IS NULL
Select Gold from  Bewohner where besitzer IS NULL
Select Gegenstand from Bewohner where besitzer IS NULL
Select Gegenstand from Bewohner where  IS NULL
Select Gegenstand from Bewohner where  'IS' NULL
Select Gegenstand from Bewohner where  'Besitzer' NULL
Select Gegenstand from Bewohner where  'Besitzer'IS NULL
Select Gegenstand from Bewohner where  'Besitzer IS' NULL
Select * from Bewohner where  Besitzer IS NULL
Select * from Bewohner where  Besitzer IS NULL
Select * from Gegenstand where  Besitzer IS NULL
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = 'Kaffeetasse'
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
Update * from Gegenstand SET= 20 where  gegenstand = 'Kaffetasse'
Update from Gegenstand SET= 20 where  gegenstand = 'Kaffetasse'
Update  Gegenstand from Besitzer SET= 20 where  gegenstand = 'Kaffetasse'
Update  Gegenstand SET  Besitzer = 20 where  Besitzer IS Null
-- Jawoll! Welche Gegenstände besitze ich nun?
-- Jawoll! Welche Gegenstände besitze ich nun?
Update  Gegenstand SET  Besitzer = 20 where  Besitzer IS Null
select  Gegenstand SET  Besitzer = 20 where  Besitzer IS Null
select * Gegenstand   Besitzer = 20 where  Besitzer IS Null
select * Gegenstand   Besitzer = 20 where  Besitzer IS 'Kaffetasse'
Select * from Besitzer = where NULL
select*from Gegenstand where Besitzer IS NULL
Select* INSERT  Gegenstand UPDATE Besitzer IS NULL
select* from Teekanne where Besitzer IS NULL
select* from gegenstand where Besitzer IS NULL
select* from gegenstand where Besitzer = 20                     
select* from Gegenstand where Besitzer = 20                     
select * from Gegenstand where Besitzer = 20                     
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
select * Bewohner where Beruf = 'Haendler OR Kaufmann AND  status' = 'friedlich'                    
select * Bewohner where Beruf = 'Haendler' OR Kaufmann AND  status = 'friedlich'                    
select * Bewohner where 'status'= 'friedlich' AND Beruf= Kaufmann OR  Haendler = 'friedlich                 
