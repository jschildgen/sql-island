-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select bewohner from dorf(2, gurkendorf, 6)
select bewohner from (2, gurkendorf, 6)
select name, dorfnr, gold from bewohner
