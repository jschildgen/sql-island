Select *
From Habitante
