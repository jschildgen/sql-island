select * from gegenstand, bewohner,dorf where bewohner.geschlecht = 'm' and not dorf.name = 'Gurkendorf' and bewohner.bewohnernr = dorf.dorfnr
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select * from gegenstand, bewohner,dorf where bewohner.geschlecht = 'm' and not dorf.name = 'Gurkendorf' and bewohner.bewohnernr = dorf.dorfnr and bewohner.dorfnr = dorf.dorfnr
select * from gegenstand, bewohner,dorf where bewohner.geschlecht = 'm' and not dorf.name = 'Gurkendorf' and bewohner.bewohnernr = dorf.dorfnr and bewohner.dorfnr = dorf.dorfnr
select * from gegenstand, bewohner,dorf where bewohner.geschlecht = 'm' and not dorf.name = 'Gurkendorf' and bewohner.bewohnernr = dorf.dorfnr and bewohner.dorfnr = dorf.dorfnr
select * from gegenstand, bewohner,dorf where bewohner.geschlecht = 'm' and not dorf.name = 'Gurkendorf' and bewohner.dorfnr = dorf.dorfnr and bewohner.bewohnernr = gegenstand.besitzer
select * from gegenstand, bewohner,dorf where bewohner.geschlecht = 'm' and dorf.name = 'Gurkendorf' and bewohner.dorfnr = dorf.dorfnr and bewohner.bewohnernr = gegenstand.besitzer
select * from gegenstand, bewohner,dorf where bewohner.geschlecht = 'm' and not dorf.name = 'Zwiebelhausen' and bewohner.dorfnr = dorf.dorfnr and bewohner.bewohnernr = gegenstand.besitzer
select * from gegenstand, bewohner,dorf where bewohner.geschlecht = 'm' and not dorf.name = 'Gurkendorf' and bewohner.dorfnr = dorf.dorfnr and bewohner.bewohnernr = gegenstand.besitzer
select * from gegenstand
select*from bewohner
select * from bewohner
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
select * from gegenstand, bewohner,dorf where bewohner.geschlecht = 'm' and not dorf.name = 'Gurkendorf' and bewohner.dorfnr = dorf.dorfnr and bewohner.bewohnernr = gegenstand.besitzer
