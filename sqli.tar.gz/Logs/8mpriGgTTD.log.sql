-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT * FROM Bewohner

-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT * FROM bewohner WHERE beruf = 'Metzger'

SELECT * FROM bewohner WHERE beruf = 'Metzger'

SELECT * FROM bewohner WHERE beruf = 'Metzger' and WHERE status = 'friedlich

SELECT * FROM bewohne WHERE status = 'friedlich

SELECT * FROM bewohner WHERE status = 'friedlich'

-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
SELECT * FROM bewohner WHERE status = 'friedlich' and WHERE beruf = 'Waffenschmied'

SELECT * FROM bewohner WHERE status = 'friedlich' AND WHERE beruf = 'Waffenschmied'

SELECT * FROM bewohner WHERE status = 'friedlich' AND beruf = 'Waffenschmied'

-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
SELECT * FROM bewohner WHERE status = 'friedlich' AND beruf = 'Waffenschmied'

SELECT * FROM bewohner WHERE beruf LIKE %schmied AND status = 'friedlich'

SELECT * FROM bewohner WHERE beruf LIKE '%schmied' AND status = 'friedlich'

-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
INSERT INTO bewohner('Arne', 20, 'männlich', 'Waffenschmied', 0, 'friedlich')

SELECT bewohnernr FROM Bewohner

SELECT bewohnernr FROM Bewohner WHERE name = 'Fremder'

-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
INSERT INTO bewohner('Fremder', '1', 'männlich', 'Waffenschmied', '0', 'friedlich')

INSERT INTO bewohner('Fremder','1','männlich','Waffenschmied, '0' , 'friedlich')

INSERT INTO bewohner('Fremder','1','männlich','Waffenschmied, 0 , 'friedlich')

INSERT INTO bewohner('Fremder','1','männlich','Waffenschmied', 0 , 'friedlich')

INSERT INTO bewohner('Fremder','1','männlich','Waffenschmied','0' , 'friedlich')

INSERT INTO bewohner('Fremder','1','männlich','Waffenschmied', 'friedlich')

INSERT INTO bewohner('Fremder','1','männlich','Waffenschmied', 'friedlich')

INSERT INTO bewohner('Fremder','1','männlich','Waffenschmied', 'friedlich')

INSERT INTO bewohner('Fremder','1','männlich','Waffenschmied', 'friedlich')

INSERT INTO bewohner('Fremder','1','m','Waffenschmied', 'friedlich')

SELECT bewohner('Fremder','1','m','Waffenschmied', 'friedlich')

SELECT * FROM bewohner('Fremder','1','m','Waffenschmied', 'friedlich')

SELECT gold FROM bewohner WHERE name = 'Fremder'

-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
SELECT * FROM WHERE name = 'Dirty Dieter'

