-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
DORF(1,Affenstadt,1)

 select 
 DORF(1,Affenstadt,1)

 insert
 DORF(1,Affenstadt,1)

select*FROM Bewohner

SELECT*FROM bewohner

SELECT*from bewohner

Select * from bewohner

-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
Select * from bewohner WHERE status='boese'

Select * from bewohner WHERE status='friedlich'

-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
Select * from bewohner WHERE status='friedlich' AND beruf='Waffenschmied'

-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
Select * from bewohner WHERE status='friedlich' AND beruf LIKE ='%schmied'

Select * from bewohner WHERE status='friedlich' AND beruf ='%schmied'

Select * from bewohner WHERE status='friedlich' AND berufLIKE ='%schmied'

Select * from bewohner WHERE status='friedlich' AND beruf LIKE ='%schmied'

Select * from bewohner WHERE status='friedlich' AND  beruf "LIKE" ='%schmied'

Select * from bewohner WHERE status='friedlich' AND  beruf like ='%schmied'

Select * from bewohner WHERE status='friedlich' AND  beruf like '%schmied'

-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
INSERT INTO bewohner(Max,1,m,Haendler,0,friedlich)

INSERT INTO bewohner VALUES (Max,1,m,Haendler,0,friedlich)

INSERT INTO bewohner VALUES(Max,1,m,Haendler,0,friedlich)

INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES(Max,1,m,Haendler,0,friedlich)

INSERT INTO bewohner VALUES("Max","1","m","Haendler","0","friedlich")

SELECT bewohnernr from bewohner name="Fremder"

SELECT bewohnernr from bewohner name='Fremder'

SELECT bewohnernr from bewohner WHERE name='Fremder'

-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
SELECT gold from bewohner WHERE name='Fremder'

-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
SELECT GEGENSTÄNDE from bewohner WHERE besitzer='IS NULL'

SELECT GEGENSTÄNDE from bewohner WHERE besitzer IS NULL

SELECT GEGENSTÄNDE from bewohner WHERE besitzer "IS NULL"

SELECT gegenstand from GEGENSTAND WHERE besitzer is NULL

SELECT gegenstand from gegenstand WHERE besitzer is NULL

SELECT gegenstand,Besitzer from gegenstand WHERE besitzer is NULL

-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = 'Kaffeetasse'
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
SELECT gegenstand SET besitzer= 20 WHERE gegenstand =" Teekanne","Ring","Eimer","Pappkarton","Gluegbirne"

SELECT gegenstand SET besitzer= 20 WHERE besitzer is NULL
SELECT gegenstand SET besitzer= 20 WHERE gegenstand besitzer is NULL
SELECT gegenstand SET besitzer= 20 WHERE gegenstand besitzer is NULL
SELECT gegenstand SET besitzer= 20 WHERE gegenstand besitzer is NULL
SELECT gegenstand SET besitzer= 20 WHERE gegenstand besitzer is NULL
SELECT gegenstand SET besitzer= 20 WHERE gegenstand = "besitzer is NULL"
SELECT gegenstand SET besitzer= 20 WHERE Besitzer is NULL
SELECT gegenstand,Besitzer set besitzer = 20 WHERE besitzer is NULL
SELECT * set besitzer = 20 WHERE besitzer is NULL
Select gegenstand set besitzer = 20 where gegenstand="*"
SELECT gegenstand,Besitzer from gegenstand WHERE besitzer is NULL
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = '*'

Select gegenstand,Besitzer Set Besitzer = 20 Where besitzer is NULL

Select gegenstand,Besitzer Set Besitzer = 20 Where gegenstand besitzer is NULL

SELECT gegenstand SET besitzer = 20 Where besitzer is NULL
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand ="Besitzer is NULL"


UPDATE gegenstand SET besitzer = 20 WHERE besitzer is NULL


-- Jawoll! Welche Gegenstände besitze ich nun?
-- Jawoll! Welche Gegenstände besitze ich nun?
SELECT gegenstand,Besitzer from gegenstand WHERE besitzer ="20"


-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
