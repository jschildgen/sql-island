-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Leider reicht das noch nicht für ein Schwert. Dann muss ich wohl doch arbeiten. Bevor ich mich jedoch irgendwo bewerbe, sollte ich vielleicht meinen Namen von Fremder auf meinen richtigen Namen ändern, ansonsten wird mich niemand einstellen.
UPDATE bewohner SET name = 'Ruediger Schmitt-Hundeburg'
UPDATE bewohner SET name = 'Ruediger Schmitt-Hundeburg'
select * from bewohner;
update bewohner set name = 'Achim Petermann'
select * from bewohner
select * from bewohner
update bewohner set name = 'Uuuuuuuuuuuuuuuuuuuuuuuwe'
update bewohner set name = 'Uuuuuuuuuuuuuuuuuuuuuuuwe'
update bewohner set name = 'Uuuuuuuuuuuuuuuuuuuuuuuwe'
update bewohner set name = 'Achim Juergens'
select * from bewohner
update bewohner set name = 'Jürgen'
select * from bewohner where beruf= 'Bäcker'
select * from bewohner where beruf= 'Baecker'
select * from bewohner where beruf = 'Baecker'
update bewohner set name = 'Jürgen Peters'
