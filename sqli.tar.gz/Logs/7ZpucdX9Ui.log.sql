-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT*FROM dorf

SELECT * FROM dorf

SELECT * FROMdorf

SELECT * FROM dorf

 SELECT * FROM dorf

SELECT * FROM Zwiebelhausen


SELECT * FROM dorf


