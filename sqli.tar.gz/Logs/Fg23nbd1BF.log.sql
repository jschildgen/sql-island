-- Ó céus, o que aconteceu? Parece que eu sou o único sobrevivente do acidente aéreo. Nossa, existem algumas aldeias nessa ilha.
SELECT * FROM aldeia
-- Parece que existem algumas pessoas vivendo nessas aldeias. Como posso ver uma lista de todos os habitantes?
SELECT * FROM habitante;
-- Cara! Estou com muita fome. Vou procurar um açougueiro e pedir algumas salsichas grátis.
-- Cara! Estou com muita fome. Vou procurar um açougueiro e pedir algumas salsichas grátis.
SELECT * FROM habitante WHERE trabalho = 'açougueiro'
-- Aqui está! Aproveite a refeição! Mas tome cuidado! Enquanto estiver desarmado, fique longe dos vilões. Nem todo mundo nessa ilha é amigável.
SELECT * FROM habitante WHERE status = 'amigavel';
SELECT * FROM habitante WHERE status = 'amigável';
-- "Não tem jeito de conseguir uma espada por conta própria. Vou tentar encontrar algum ferreiro amigável para forjar uma espada para mim (""armamento-ferreiro""). (Dica: Você pode combinar predicados na cláusula WHERE usando o AND.)"
-- "Não tem jeito de conseguir uma espada por conta própria. Vou tentar encontrar algum ferreiro amigável para forjar uma espada para mim (""armamento-ferreiro""). (Dica: Você pode combinar predicados na cláusula WHERE usando o AND.)"
SELECT * FROM habitante WHERE status = 'amigável' AND trabalho = 'armamento-ferreiro';
-- "Isso não parece nada bom. Talvez outro aldeão amigável com perícia em ferraria possa ajudá-lo, por exemplo qualquer ferreiro. Tente: use LIKE ""%ferreiro"" para encontrar os habitantes cujo trabalho termine com ""ferreiro"" (% é um coringa para qualquer número de caracteres). "
-- "Isso não parece nada bom. Talvez outro aldeão amigável com perícia em ferraria possa ajudá-lo, por exemplo qualquer ferreiro. Tente: use LIKE ""%ferreiro"" para encontrar os habitantes cujo trabalho termine com ""ferreiro"" (% é um coringa para qualquer número de caracteres). "
SELECT * FROM habitante WHERE status = 'amigável' AND trabalho LIKE '%ferreiro';
-- Olá estranho! Aonde está indo? Eu sou Paul, o prefeito da Cidade Macaco. Irei registrá-lo como cidadão.
-- Olá estranho! Aonde está indo? Eu sou Paul, o prefeito da Cidade Macaco. Irei registrá-lo como cidadão.
INSERT INTO habitante (nome, idaldeia, gênero, trabalho, ouro, status) VALUES ('Estranho', 1, '?', '?', 0, '?')
-- Não precisa me chamar de estranho! Qual é meu idpessoa? (Dica: Em consultas formais, o * significa todas as colunas. Ao invés de utilizá-lo, você pode endereçar uma ou mais colunas, separadas por vírgula, e você obterá somente as colunas que precisar!)
SELECT idpessoa FROM habitante WHERE nome = 'Estranho';
-- Olá Ernesto! Quanto custa uma espada?
-- Olá Ernesto! Quanto custa uma espada?
SELECT idpessoa FROM habitante WHERE nome = 'Estranho';
SELECT ouro FROM habitante WHERE idpessoa = 20;
-- Nossa, o olho da cara! Deve haver outra opção para ganhar ouro além de ter que trabalhar. Talvez eu possa coletar itens sem dono e vendê-los. Posso fazer uma lista de itens que não pertencem a ninguém? (Dica: você pode identificar itens sem dono com: WHERE proprietario IS NULL)
-- Nossa, o olho da cara! Deve haver outra opção para ganhar ouro além de ter que trabalhar. Talvez eu possa coletar itens sem dono e vendê-los. Posso fazer uma lista de itens que não pertencem a ninguém? (Dica: você pode identificar itens sem dono com: WHERE proprietario IS NULL)
SELECT * FROM item WHERE proprietario IS NULL;
SELECT * FROM item WHERE proprietário IS NULL;
-- Eba, uma xícara! Vamos coletá-la!
-- Eba, uma xícara! Vamos coletá-la!
UPDATE item SET proprietário = 20 WHERE item = 'xícara'
-- Você sabe um truque para coletar todos os itens sem dono?
UPDATE item
SET proprietário = 20
proprietário IS NULL;
UPDATE item SET proprietário = 20 WHERE proprietário IS NULL;
-- Agora liste todos os itens que eu tenho!
-- Agora liste todos os itens que eu tenho!
SELECT *
FROM ITEM
WHERE idpessoa = 20;
SELECT *
FROM ITEM
WHERE proprietário = 20;
-- Encontre um habitante amigável que seja ou negociante ou mercador. Talvez ele queira comprar algum dos meus itens. (Dica: Quando utilizar tanto AND quanto OR , não esqueça de inserir corretamente os parênteses.)
-- Encontre um habitante amigável que seja ou negociante ou mercador. Talvez ele queira comprar algum dos meus itens. (Dica: Quando utilizar tanto AND quanto OR , não esqueça de inserir corretamente os parênteses.)
