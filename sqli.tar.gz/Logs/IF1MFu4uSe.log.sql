-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT * FROM BEWOHNER;
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT * FROM BEWOHNER;
SELECT * FROM BEWOHNER where BERUF= 'FRIEDLICH'
SELECT * FROM BEWOHNER where BERUF= 'friedlich'
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and '
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and Name= 'ERNST PENG'
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and Gegenstand WHERE Besitzer= Null
SELECT * FROM BEWOHNER where BERUF='Waffenschmied' AND status= 'friedlich'and Gegenstand from Bewohnernr.2
SELECT * gegenstand from gegenstand where besitzer= '2'
SELECT * gegenstand from gegenstand where besitzer= '2'
SELECT  Bewohner from bewohnernr.2 where friedlich
SELECT * from Bewohner where status ='friedlich'
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
SELECT * From bewohnernr.2 where status= friedlich and Waffenschmied
SELECT * From beruf= 'Waffenschmied' where Status= 'friedlich'
SELECT * From beruf 'Waffenschmied' where Status= 'friedlich'
SELECT * From Bewohnernr.2 where Beruf= 'Waffenschmied' where Status= 'friedlich'
SELECT * From Bewohner Ernst Peng where Beruf= 'Waffenschmied' where Status= 'friedlich'
SELECT * From Bewohnernr.2 where Status= 'friedlich'
