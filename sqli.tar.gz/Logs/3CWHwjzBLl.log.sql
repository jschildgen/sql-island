-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
update bewohner set name = 'Peter Unlustig' where name = 'Anton Jandek'
update bewohner set name = 'Peter Unlustig' where bewohnernr = 20
select * from bewohner
