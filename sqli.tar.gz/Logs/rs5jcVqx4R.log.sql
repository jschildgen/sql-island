-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select * from Bewohner;
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
select * from Bewohner where status = 'friedlich';
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
select * from Bewohner where status = 'friedlich' and beruf = 'Hufschmied';
select * from Bewohner where status = 'friedlich' and beruf = 'Waffenschmied';
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
select * from Bewohner where status = 'friedlich' and beruf like '%schmied';
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
select bewohnernr from bewohner where name = 'Fremder';
-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
select gold from Bewohner where bewohnernr = 20;
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
select * from Gegenstaende where besitzer is null;
select * from gegenstand where besitzer is null;
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = 'Kaffeetasse'
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
update gegenstand set besitzer = 20 where besitzer is null;
-- Jawoll! Welche Gegenstände besitze ich nun?
-- Jawoll! Welche Gegenstände besitze ich nun?
select * from gegenstand where besitzer = 20;
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
select * from Bewohner where beruf in ('Haendler', 'Kaufmann') and status = 'friedlich';
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
update gegenstand set besitzer = 15 where gegenstand in ('Ring', 'Teekanne');
-- Hier hast du einen Haufen Gold!
-- Hier hast du einen Haufen Gold!
UPDATE bewohner SET gold = gold + 120 WHERE bewohnernr = 20
-- Leider reicht das noch nicht für ein Schwert. Dann muss ich wohl doch arbeiten. Bevor ich mich jedoch irgendwo bewerbe, sollte ich vielleicht meinen Namen von Fremder auf meinen richtigen Namen ändern, ansonsten wird mich niemand einstellen.
update Bewohner set name = 'Yugi' where bewohnernr = 20;
-- In meiner Freizeit backe ich gerne. Ich glaube, ich verdiene mir ein bisschen Geld als Bäcker. Zeige mir alle Bäcker. Tipp: Mit ORDER BY gold kannst du die Liste sortieren, mit ORDER BY gold DESC steht sogar der reichste Bäcker oben.
-- In meiner Freizeit backe ich gerne. Ich glaube, ich verdiene mir ein bisschen Geld als Bäcker. Zeige mir alle Bäcker. Tipp: Mit ORDER BY gold kannst du die Liste sortieren, mit ORDER BY gold DESC steht sogar der reichste Bäcker oben.
select * from Bewohner where beruf = 'Baecker' order by gold desc;
-- Hi, da bist du ja wieder! Soso, Yugi heißt du also. Und du willst als Bäcker arbeiten? Da sag ich nicht nein. Ich zahle dir pro hundert Brötchen, die du mir bäckst, 1 Gold.
-- Hi, da bist du ja wieder! Soso, Yugi heißt du also. Und du willst als Bäcker arbeiten? Da sag ich nicht nein. Ich zahle dir pro hundert Brötchen, die du mir bäckst, 1 Gold.
UPDATE bewohner SET gold = gold + 100 - 150 WHERE bewohnernr = 20
-- Hier ist dein neues Schwert, Yogo! Nun kannst du überall hin!
INSERT INTO gegenstand (gegenstand, besitzer) VALUES ('Schwert', 20)
-- Gibt es auf der Insel einen Piloten? Er könnte mich nach Hause fliegen.
select * from Bewohner where beruf = 'Pilot';
-- Es ist schrecklich! Dirty Dieter hält den Piloten gefangen! Ich verrate dir einen Trick, wie wir schnell herausfinden können, in welchem Dorf Dirty Dieter wohnt.
-- Es ist schrecklich! Dirty Dieter hält den Piloten gefangen! Ich verrate dir einen Trick, wie wir schnell herausfinden können, in welchem Dorf Dirty Dieter wohnt.
SELECT dorf.name FROM dorf, bewohner WHERE dorf.dorfnr = bewohner.dorfnr AND bewohner.name = 'Dirty Dieter'
-- Auf diese Weise kannst du das Dorf mit der Dorf-Nummer suchen, die bei Dirty Dieter im Feld dorfnr steht. Ein solch genialer Ausdruck nennt sich Verbund oder Join.
select b.* from Bewohner b join Dorf d on b.haeuptling = b.bewohnernr
where name = 'Zwiebelhausen';
select b.* from Bewohner b join Dorf d on b.haeuptling = b.bewohnernr
where d.name = 'Zwiebelhausen';
select b.* from Bewohner b join Dorf d on d.haeuptling = b.bewohnernr
where d.name = 'Zwiebelhausen';
select b.name from Bewohner b join Dorf d on d.haeuptling = b.bewohnernr
where d.name = 'Zwiebelhausen';
-- Hm, wie viele Einwohner hat eigentlich Zwiebelhausen?
-- Hm, wie viele Einwohner hat eigentlich Zwiebelhausen?
SELECT COUNT(*) FROM bewohner, dorf WHERE dorf.dorfnr = bewohner.dorfnr AND dorf.name = 'Zwiebelhausen'
-- Hallo Yugi, Dirty Dieter hält den Piloten im Haus seiner Schwester gefangen. Soll ich dir verraten, wie viele Frauen es in Zwiebelhausen gibt? Ach was, das kannst du schon selbst herausfinden! (Hinweis: Frauen erkennt man an geschlecht = 'w')
select count(b.bewohnernr) from Bewohner b join Dorf d on b.dorfnr = d.dorfnr
where d.name = 'Zwiebelhausen' and b.geschlecht = 'w';
-- Ha, nur eine Frau. Mal schauen, wie sie heißt.
-- Ha, nur eine Frau. Mal schauen, wie sie heißt.
select b.name from Bewohner b join Dorf d on b.dorfnr = d.dorfnr
where d.name = 'Zwiebelhausen' and b.geschlecht = 'w';
-- Yugi, gib mir alles Gold, was die Bewohner von unserem Nachbardorf Gurkendorf zusammen besitzen und ich lasse den Piloten frei! Du willst wissen, wie viel das ist? Ich zeige es dir!
-- Yugi, gib mir alles Gold, was die Bewohner von unserem Nachbardorf Gurkendorf zusammen besitzen und ich lasse den Piloten frei! Du willst wissen, wie viel das ist? Ich zeige es dir!
SELECT SUM(bewohner.gold) FROM bewohner, dorf WHERE dorf.dorfnr = bewohner.dorfnr AND dorf.name = 'Gurkendorf'
-- So viel Gold werde ich niemals allein durch Brötchenbacken verdienen können. Ich muss mir etwas anderes einfallen lassen. Wenn ich Gegenstände verkaufe und zusätzlich noch als Bäcker arbeite, kann ich maximal so viel Gold bekommen, wie die Händler, Kaufmänner und Bäcker zusammen besitzen. Wie viel ist das?
select sum(gold) from bewohner where beruf in ('Haendler', 'Kaufmann', 'Baecker');
-- Schauen wir mal die gesamten sowie durchschnittlichen Goldvorräte der einzelnen Berufe an.
-- Schauen wir mal die gesamten sowie durchschnittlichen Goldvorräte der einzelnen Berufe an.
SELECT beruf, SUM(bewohner.gold), AVG(bewohner.gold) FROM bewohner GROUP BY beruf ORDER BY AVG(bewohner.gold)
-- Interessant, die Metzger haben also das meiste Gold. Warum auch immer... Wie viel Gold haben im Durchschnitt die einzelnen Bewohnergruppen je nach Status (friedlich, böse, gefangen)?
select status, sum(gold), avg(gold) from Bewohner group by status order by avg(gold)
select status, avg(gold) from Bewohner group by status order by avg(gold)
-- Dann kann ich auch gleich Dirty Dieter mit dem Schwert töten und den Piloten befreien.
-- Dann kann ich auch gleich Dirty Dieter mit dem Schwert töten und den Piloten befreien.
DELETE FROM bewohner WHERE name = 'Dirty Dieter'
-- Heeeey! Jetzt bin ich aber sauer! Was tust du wohl als nächstes, Yugi?
update Bewohner set status = 'friedlich' where name = 'Dirty Doerthe';
delete from bewohner where name = 'Dirty Doerthe';
-- Yeah! Jetzt muss ich nur noch den Piloten befreien.
-- Yeah! Jetzt muss ich nur noch den Piloten befreien.
update Bewohner set status = 'friedlich' where bewohnernr = 8;
-- Vielen vielen Dank, Yugi! Jetzt fliege ich dich nach Hause.
-- Vielen vielen Dank, Yugi! Jetzt fliege ich dich nach Hause.
UPDATE bewohner SET status = 'ausgewandert' WHERE bewohnernr = 20
