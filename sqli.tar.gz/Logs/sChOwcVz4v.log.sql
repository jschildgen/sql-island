-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select * from bewohner
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
select* from bewohner where not ='boese'
select* from bewohner where ='friedlich'
select * from bewohner were not status ='boese'
select * from bewohner were status ='frielich'
select * from bewohner wehere not status ='frielich'
select * from bewohner wehere status ='frielich'
select * from bewohner wehere status ='frdielich'
select * from bewohner wehere status ='friedlich'
select * from bewohner where status ='firedlich'
select * from bewohner where status ='firedlich'
