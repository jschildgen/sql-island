-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
select population from village
select chief from village
select villageid,name,chief from village
SELECT * FROM village
SELECT * FROM village
SELECT villageid FROM village
SELECT number FROM village
SELECT chief FROM village
SELECT * FROM INHABITANT 
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
SELECT * FROM inhabitant WHERE job = 'butcher'
-- There you are! Enjoy your meal! But take care of yourself. As long as you are unarmed, stay away from villains. Not everyone on this island is friendly.
SELECT * FROM INHABITANT 
WHO = FRIENDLY
SELECT * FROM INHABITANT 
WHERE = FRIENDLY
SELECT * FROM INHABITANT 
WHERE = 'FRIENDLY'
SELECT * FROM STATE 
WHERE = 'FRIENDLY'
SELECT * FROM STATE 

SELECT * FROM INHABITANT
WHERE STATE = friendly

SELECT * FROM INHABITANT
WHERE STATE = 'friendly'

-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
SELECT * FROM INHABITANT
WHERE STATE = 'friendly'
AND JOB = 'weaponsmith'

-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
SELECT * FROM INHABITANT
WHERE STATE = 'friendly'
AND JOB = '%smith' 

SELECT * FROM INHABITANT
WHERE STATE = 'friendly'
job LIKE '%smith' 

SELECT * FROM INHABITANT
WHERE STATE = 'friendly' AND job LIKE '%smith' 

-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
INSERT INTO inhabitant (name, villageid, gender, job, gold, state) VALUES ('Stranger', 1, '?', '?', 0, '?')
-- No need to call me stranger! What's my personid? (Hint: In former queries, the * stands for: all columns. Instead of the star, you can also address one or more columns (seperated by a comma) and you will only get the columns you need.)
SELECT PERSONID FROM INHABITANT
WHERE STATE = 'friendly' AND job LIKE '%smith' 

SELECT PERSONID FROM INHABITANT
 

SELECT PERSONID FROM INHABITANT
 WHERE NAME = 'STRANGER'
 

SELECT PERSONID FROM INHABITANT
 WHERE NAME = STRANGER
 

SELECT PERSONID FROM INHABITANT
 WHERE NAME = 'Stranger'
 

-- Hi Ernest! How much is a sword?
-- Hi Ernest! How much is a sword?
SELECT PERSONID FROM INHABITANT
 WHERE NAME = 'Stranger'
 

SELECT gold FROM INHABITANT
 WHERE NAME = 'Stranger'
 

-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
SELECT item FROM INHABITANT
WHERE owner IS NULL
 

SELECT item FROM ITEM
WHERE owner IS NULL
 

SELECT item FROM OWNER
WHERE owner IS NULL
 

SELECT OWNER FROM ITEM
WHERE owner IS NULL
 

SELECT owner FROM ITEM
WHERE owner IS NULL
 

SELECT item FROM ITEM
WHERE owner IS NULL
 

SELECT * FROM ITEM
WHERE owner IS NULL
 

-- Yay, a coffee cup. Let's collect it!
-- Yay, a coffee cup. Let's collect it!
UPDATE item SET owner = 20 WHERE item = 'coffee cup'
-- Do you know a trick how to collect all the ownerless items?
SELECT * FROM ITEM
WHERE owner IS NULL
 

SELECT item FROM ITEM
WHERE owner IS NULL
 

SELECT item 
WHERE owner IS NULL
 

collect item 
WHERE owner IS NULL
 

insert item from item
WHERE owner IS NULL
 

select item from item
WHERE owner IS NULL
 

select * from item 
WHERE owner IS NULL
 

select * from item 


 

select * From Item
where owner = null
set owner = '20'



 

update Item
set owner = '20'
where owner = null




 

update Item
set owner = '20'
where owner = 'null'




 

update Item
set owner = 20
where owner = null




 

update Item
set owner = 20
where owner = 'null'




 

update Item
set owner = 20
where owner is null




 

-- Now list all of the items I have!
-- Now list all of the items I have!
select * Item
where owner = '20'




 

select * Item
where owner = 'stranger'




 

select * Item
where owner is 20




 

select * Item
where owner is '20'




 

select * Item
where owner = 20




 

select * Item
where owner = '20'




 

select * Item
where personid = '20'




 

select Item from item
where  = '20'




 

select Item from item
where owner = '20'




 

select * item
where owner = '20'




 

select * from item
where owner = '20'




 

-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
select * from inhabitant
where job = 'dealer' and 'merchant'




 

select job from inhabitant
where job = 'dealer' and 'merchant'




 

select job from inhabitant
where job = 'dealer' 




 

select job from inhabitant
where job = 'dealer' and job =  'merchant' 




 

select job from inhabitant
where job = 'dealer' and job = 'merchant' 




 

select job from inhabitant
where job is 'dealer' or 'merchant' 




 

select job from inhabitant
where job is 'dealer' or job is 'merchant' 




 

