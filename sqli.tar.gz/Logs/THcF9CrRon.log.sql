update gegenstand set besitzer = 15 where gegenstand = 'Ring' or gegenstand = 'Teekanne'
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select * from bewohner
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
