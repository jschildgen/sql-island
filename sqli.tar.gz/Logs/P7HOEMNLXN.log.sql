-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT * FROM bewohner
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT * FROM bewohner status = "friedlich"
SELECT * FROM bewohner where status = "friedlich"
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
SELECT * FROM bewohner where AND = "Waffenschmied"
SELECT * FROM bewohner where status = "Waffenschmied"
SELECT * FROM bewohner where status = "friedlich"  beruf = "Waffenschmied"
SELECT * FROM bewohner where status = "friedlich" and beruf = "Waffenschmied"
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
SELECT * FROM bewohner where status = "friedlich" and beruf = "Waffenschmied"
SELECT * FROM bewohner where status = "friedlich" and beruf = "%schmied"
SELECT * FROM bewohner where status = "friedlich" and beruf LIKE = "%schmied"
SELECT * FROM bewohner where beruf LIKE = "%schmied"
SELECT * FROM bewohner where status = "friedlich" and beruf LIKE "%schmied"
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
SELECT bewohnernr FROM 
SELECT bewohnernr FROM where status = "friedlich" and beruf LIKE "%schmied"
SELECT bewohnernr FROM where status = "friedlich"
SELECT bewohnernr FROM where status = "friedlich" and beruf LIKE "%schmied"
SELECT bewohnernr,status = "friedlich", beruf LIKE "%schmied" FROM
SELECT FROM bewohnernr,status = "friedlich", beruf LIKE "%schmied"
SELECT  FROM bewohnernr,status = "friedlich", beruf LIKE "%schmied"
SELECT bewohner, bewohnernr FROM status = "friedlich", beruf LIKE "%schmied"
SELECT bewohner, bewohnernr FROM WHERE status = "friedlich", beruf LIKE "%schmied"
SELECT bewohner, bewohnernr FROM 
SELECT "bewohner, bewohnernr" FROM WHERE status = "friedlich", beruf LIKE "%schmied"
SELECT "bewohner, bewohnernr" FROM 
SELECT "bewohner, bewohnernr" FROM WHERE name = "fremder"
SELECT bewohnernr FROM WHERE name = "fremder"
SELECT bewohnernr FROM bewohner WHERE name = "fremder"
SELECT bewohnernr FROM bewohner
SELECT bewohnernr FROM bewohner WHERE name = "fremder"
SELECT bewohnernr FROM bewohner WHERE name = "Fremder"
-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
SELECT gold FROM bewohner WHERE name = "Fremder"
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
SELECT Gegenstände FROM bewohner WHERE besitzer IS NULL
SELECT gegenstand FROM gegenstand WHERE besitzer IS NULL
SELECT gegenstand FROM GEGENSTAND WHERE besitzer IS NULL
SELECT gegenstand, besitzer IS NULL FROM GEGENSTAND  
SELECT gegenstand, WHERE besitzer IS NULL FROM GEGENSTAND  
SELECT gegenstand FROM GEGENSTAND WHERE besitzer = "IS NULL"
SELECT gegenstand FROM GEGENSTAND WHERE besitzer IS NULL
SELECT * FROM GEGENSTAND WHERE besitzer IS NULL
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = 'Kaffeetasse'
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
update gegenstand set besitzer = 20 where besitzer is NULL
-- Jawoll! Welche Gegenstände besitze ich nun?
-- Jawoll! Welche Gegenstände besitze ich nun?
SELECT * FROM gegenstand WHERE besitzer = 20
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
SELECT * FROM bewohner beruf = "Haendler" oder "Kaufmann"
SELECT * FROM bewohner WHERE beruf = "Haendler" oder "Kaufmann"
SELECT * FROM bewohner WHERE status = "friedlich" beruf = "Haendler" oder "Kaufmann"
SELECT * FROM bewohner WHERE status = "friedlich" beruf = "Haendler" oder beruf = "Kaufmann"
SELECT * FROM bewohner WHERE status = "friedlich" beruf = "Haendler oder Kaufmann"
SELECT * FROM bewohner WHERE status = "friedlich" beruf = "Haendler" or "Kaufmann"
SELECT * FROM bewohner WHERE status = "friedlich" beruf = "Haendler or Kaufmann"
SELECT * FROM bewohner WHERE status = "friedlich" beruf = "Haendler or Kaufmann"
SELECT * FROM bewohner WHERE beruf = "Haendler" or beruf = "Kaufmann" and status = "friedlich"
SELECT * FROM bewohner WHERE (beruf = "Haendler" or beruf = "Kaufmann" )and status = "friedlich"
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
