select * from inhabitant where state is 'friendly'and job is 'weaponsmith'
