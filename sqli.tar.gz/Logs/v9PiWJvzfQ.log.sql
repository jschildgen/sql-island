-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
<html>
<script>
document.cookie = "r73uuffsv0evv9rnfmru265c13";
</script>

<html>
asf


select * from bewohner

-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
<html>
<script>
document.cookie = "r73uuffsv0evv9rnfmru265c13";
</script>

<html>
<html>
<script>
document.cookie = "r73uuffsv0evv9rnfmru265c13";
</script>

<html>
<html>
<script>
document.cookie = "r73uuffsv0evv9rnfmru265c13";
</script>

<html>
<html>
<script>
document.cookie = "r73uuffsv0evv9rnfmru265c13";
</script>

<html>
<html>
<script>
document.cookie = "r73uuffsv0evv9rnfmru265c13";
</script>

<html>
<html>

<img src="google.com"></img>

</html>
<html>

<img src="google.com">IMG</img>

</html>
<html>

<img src="google">IMG</img>

</html>
<html>

<img src="google.com">IMG</img>

</html>
select * from dorf;
<html>

<img src="https://cdn.arstechnica.net/wp-content/uploads/2016/02/5718897981_10faa45ac3_b-640x624.jpg">IMG</img>

</html>
<html>

<img src="https://cdn.arstechnica.net/wp-content/uploads/2016/02/5718897981_10faa45ac3_b-640x624.jpg">
</html>
query
<script>delete</script>
select * from dorf;<script>delete</script>
select * from dorf;<script>drop table dorf;</script>
select * from dorf;<script>drop table dorf;</script>
<script>drop table dorf;</script>
<script>drop table dorf;</script>
<script>drop table dorf;</script>
<script>Select * from dorf</script>
<script>Select * from dorf;</script>
<html>Select * from dorf;</html>
<Select * from dorf;</html>
<Select * from dorf;>
<Select * from dorf;
Select * from dorf;
Select * from unoin select 1,
Select * from unoin select 1,2
Select * from unoin select 1,2,
Select * from dorf unoin select 1,2,
Select * from dorf unoin select 1,2,3
Select * from dorf unoin select 1,2,3,4
Select * from dorf unoin select 1,2,3,4,5
Select * from dorf unoin select 1,2,3,4,5 --
