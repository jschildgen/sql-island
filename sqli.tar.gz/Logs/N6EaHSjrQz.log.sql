-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT*dorfnr 1
SELECT BEWOHNER
SELECT 1
SELECT  * 1

SELECT  * BEWOHNER

SELECT*FROM dorf

SELECT*DORF

SELECT*FROM DORF

SELECT*DORF 1

SELECT 1

SELECT DORF

DESCRIBE DORF

SELECT DORF

SELECT dorfnr

SELECT name

SELECT * FROM dorf


SELECT * FROM BEWOHNER


-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT * FROM bewohner WHERE status = 'boese'


SELECT * FROM bewohner WHERE status = 'friendlich'


SELECT * FROM bewohner WHERE status = 'friedlich'


-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
SELECT * FROM bewohner WHERE beruf = 'Waffenschmied'


SELECT * FROM bewohner WHERE beruf = 'Waffenschmied'


SELECT * FROM bewohner WHERE beruf = 'Waffenschmied' AND status = 'friedlich'


-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
SELECT * FROM bewohner WHERE beruf = '%schmied' AND status = 'friedlich'


SELECT * FROM bewohner WHERE beruf LIKE '%schmied' AND status = 'friedlich'


-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
SELECT 1 FROM bewohner WHERE beruf LIKE '%schmied' AND status = 'friedlich'


INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, 'm', 'Pro', 9000, 'friedlich')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Pana', 1, 'm', 'Pro', 9000, 'friedlich')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Pana', 1, 'm', 'Waffenschmied', 9000, 'friedlich')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Pana', 1, 'm', 'Schmied', 9000, 'friedlich')
INSERT INTO BEWOHNER (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Pana', 1, 'm', 'Schmied', 9000, 'friedlich')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Pana', 1, 'm', 'Schmied', 0, 'friedlich')
INSERT INTO bewohner VALUES ('Pana', 1, 'm', 'Schmied', 0, 'friedlich')
INSERT INTO bewohner VALUES ('Pana', 1, 'm', 'Schmied', 10, 'friedlich')
INSERT INTO bewohner VALUES (12, 'Pana', 1, 'm', 'Schmied', 10, 'friedlich')
INSERT INTO bewohner VALUES (999, 'Pana', 1, 'm', 'Schmied', 10, 'friedlich')
INSERT INTO bewohner(name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Pana', 1, 'm', 'Schmied', 10, 'friedlich')
INSERT INTO bewohner(name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Pana B', 1, 'm', 'Schmied', 10, 'friedlich')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
INSERT bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf) VALUES ('Pana', 1, 'm', 'bus')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf) VALUES ('Pana', *, 'm', 'bus')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf) VALUES ('Pana', 12, 'm', 'bus')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf) VALUES ('Pana', ?, 'm', 'bus')
INSERT INTO bewohner (name, dorfnr, geschlecht) VALUES ('Pana', ?, 'm')
INSERT INTO bewohner (name, dorfnr, geschlecht) VALUES ('Pana', 99, 'm')
INSERT INTO bewohner (name, geschlecht) VALUES ('Pana', 'm')
INSERT INTO bewohner (name, geschlecht, beruf) VALUES ('Pana', 'm', 'bus')
INSERT INTO bewohner (name, geschlecht, beruf) VALUES ('Pana', 'm', 'Waffenschmied')
INSERT INTO bewohner (name, geschlecht, beruf) VALUES ('Pana', 'm', 'LOST')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Pana', '3','m', 'LOST', 1, 'friedlich')
INSERT INTO bewohner (12, 'Pana', '3','m', 'LOST', 1, 'friedlich')
INSERT INTO bewohner ('12', 'Pana', '3','m', 'LOST', 1, 'friedlich')
INSERT INTO bewohner ('12', 'Pana', '3','m', 'LOST', '1', 'friedlich')
INSERT INTO bewohner ('12', 'Pana', '3', 'm', 'LOST', '1', 'friedlich')
INSERT INTO bewohner ('12', 'Pana', '3', 'm', 'Waffenschmied', '1', 'friedlich')
INSERT bewohner ('12', 'Pana', '3', 'm', 'Waffenschmied', '1', 'friedlich')
INSERT INTO bewohner ('12', 'Pana', '3', 'm', 'Waffenschmied', '1', 'friedlich')
INSERT INTO bewohner VALUES ('12', 'Pana', '3', 'm', 'Waffenschmied', '1', 'friedlich')
INSERT INTO bewohner VALUES ('Pana', '3', 'm', 'Waffenschmied', '1', 'friedlich')
INSERT INTO bewohner VALUES (999, 'Pana', '3', 'm', 'Waffenschmied', '1', 'friedlich')
INSERT INTO bewohner VALUES (1,'Pana', '3', 'm', 'Waffenschmied', '1', 'friedlich')
SELECT * FROM bewohner
INSERT INTO bewohner(bewohernr) VALUES(333) 
INSERT INTO bewohner(bewohnernr) VALUES(333) 
SELECT * FROM bewohner
