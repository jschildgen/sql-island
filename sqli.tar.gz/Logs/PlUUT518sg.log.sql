-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT bewohnernr FROM BEWOHNER  
SELECT bewohnernr,name,dorfnr FROM BEWOHNER  
SELECT bewohnernr,name,dorfnr,geschlecht,beruf,gold,status FROM BEWOHNER  
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT status FROM bewohner 
SELECT status,name FROM bewohner 
SELECT status,name,bewohnernr,geschlecht FROM bewohner 
SELECT name,status FROM bewohner 
SELECT name,status, friedlich FROM bewohner 
SELECT bewohnernr,name,dorfnr,geschlecht,beruf,gold,status FROM bewohner 
SELECT bewohnernr,name,dorfnr,geschlecht,beruf,status FROM bewohner 
SELECT bewohnernr,name,geschlecht,beruf,status FROM bewohner 
SELECT name,geschlecht,beruf,status FROM bewohner 
SELECT name,geschlecht,status FROM bewohner 
SELECT bewohnernr,name,geschlecht,status FROM bewohner 
SELECT bewohnernr,name,status FROM bewohner 
SELECT bewohnernr,name,dorfnr,geschlecht,beruf,gold,status FROM bewohner 
SELECT bewohnernr,name,dorfnr,geschlecht,beruf,status FROM bewohner 
SELECT bewohnernr,dorfnr,geschlecht,beruf,status FROM bewohner 
SELECT bewohnernr,name,geschlecht,beruf,status FROM bewohner 
SELECT bewohnernr,name,dorfnr,geschlecht,beruf,status FROM bewohner 
