-- Ó céus, o que aconteceu? Parece que eu sou o único sobrevivente do acidente aéreo. Nossa, existem algumas aldeias nessa ilha.
SELECT * FROM aldeia
-- Parece que existem algumas pessoas vivendo nessas aldeias. Como posso ver uma lista de todos os habitantes?
select * from habitante
-- Cara! Estou com muita fome. Vou procurar um açougueiro e pedir algumas salsichas grátis.
-- Cara! Estou com muita fome. Vou procurar um açougueiro e pedir algumas salsichas grátis.
SELECT * FROM habitante WHERE trabalho = 'açougueiro'
-- Aqui está! Aproveite a refeição! Mas tome cuidado! Enquanto estiver desarmado, fique longe dos vilões. Nem todo mundo nessa ilha é amigável.
select * from habitante
where status='amigável'
-- "Não tem jeito de conseguir uma espada por conta própria. Vou tentar encontrar algum ferreiro amigável para forjar uma espada para mim (""armamento-ferreiro""). (Dica: Você pode combinar predicados na cláusula WHERE usando o AND.)"
-- "Não tem jeito de conseguir uma espada por conta própria. Vou tentar encontrar algum ferreiro amigável para forjar uma espada para mim (""armamento-ferreiro""). (Dica: Você pode combinar predicados na cláusula WHERE usando o AND.)"
select * from habitante
where status='amigável' and trabalho='armamento-ferreiro'
-- "Isso não parece nada bom. Talvez outro aldeão amigável com perícia em ferraria possa ajudá-lo, por exemplo qualquer ferreiro. Tente: use LIKE ""%ferreiro"" para encontrar os habitantes cujo trabalho termine com ""ferreiro"" (% é um coringa para qualquer número de caracteres). "
-- "Isso não parece nada bom. Talvez outro aldeão amigável com perícia em ferraria possa ajudá-lo, por exemplo qualquer ferreiro. Tente: use LIKE ""%ferreiro"" para encontrar os habitantes cujo trabalho termine com ""ferreiro"" (% é um coringa para qualquer número de caracteres). "
select * from habitante
where status='amigável' and trabalho like '%ferreiro'
-- Olá estranho! Aonde está indo? Eu sou Paul, o prefeito da Cidade Macaco. Irei registrá-lo como cidadão.
-- Olá estranho! Aonde está indo? Eu sou Paul, o prefeito da Cidade Macaco. Irei registrá-lo como cidadão.
INSERT INTO habitante (nome, idaldeia, gênero, trabalho, ouro, status) VALUES ('Estranho', 1, '?', '?', 0, '?')
-- Não precisa me chamar de estranho! Qual é meu idpessoa? (Dica: Em consultas formais, o * significa todas as colunas. Ao invés de utilizá-lo, você pode endereçar uma ou mais colunas, separadas por vírgula, e você obterá somente as colunas que precisar!)
select * from habitante
where nome='Estranho'
select idpessoa from habitante
where nome='Estranho'
-- Olá Ernesto! Quanto custa uma espada?
-- Olá Ernesto! Quanto custa uma espada?
select ouro from habitante
where nome='Estranho'
-- Nossa, o olho da cara! Deve haver outra opção para ganhar ouro além de ter que trabalhar. Talvez eu possa coletar itens sem dono e vendê-los. Posso fazer uma lista de itens que não pertencem a ninguém? (Dica: você pode identificar itens sem dono com: WHERE proprietario IS NULL)
-- Nossa, o olho da cara! Deve haver outra opção para ganhar ouro além de ter que trabalhar. Talvez eu possa coletar itens sem dono e vendê-los. Posso fazer uma lista de itens que não pertencem a ninguém? (Dica: você pode identificar itens sem dono com: WHERE proprietario IS NULL)
select * from item
where proprietário is null
-- Eba, uma xícara! Vamos coletá-la!
-- Eba, uma xícara! Vamos coletá-la!
UPDATE item SET proprietário = 20 WHERE item = 'xícara'
-- Você sabe um truque para coletar todos os itens sem dono?
update item set proprietário=20
where proprietário is null
-- Agora liste todos os itens que eu tenho!
-- Agora liste todos os itens que eu tenho!
select * from item
where proprietário=20
-- Encontre um habitante amigável que seja ou negociante ou mercador. Talvez ele queira comprar algum dos meus itens. (Dica: Quando utilizar tanto AND quanto OR , não esqueça de inserir corretamente os parênteses.)
-- Encontre um habitante amigável que seja ou negociante ou mercador. Talvez ele queira comprar algum dos meus itens. (Dica: Quando utilizar tanto AND quanto OR , não esqueça de inserir corretamente os parênteses.)
select * from habitante
where status='amigável' and (trabalho='negociante' or trabalho='mercador')
-- Eu gostaria do bule e do anel. O resto não é nada além de sucata. Por favor me dê esses dois itens. Meu idpessoa é 15.
-- Eu gostaria do bule e do anel. O resto não é nada além de sucata. Por favor me dê esses dois itens. Meu idpessoa é 15.
update item set proprietário=15
where item='bule' and item'anel'
update item set proprietário=15
where item='bule' and item='anel'
select * item
select * from item
update item set proprietário=15
where item='bule'
update item set proprietário=15
where item='anel'
-- Aqui, um pouco de ouro!
-- Aqui, um pouco de ouro!
UPDATE habitante SET ouro = ouro + 120 WHERE idpessoa = 20
-- Infelizmente, não é ouro suficiente para comprar uma espada. Parece que terei que trabalhar mesmo. Talvez não seja uma má ideia trocar meu nome de Estranho para meu nome real antes de me candidatar à um trabalho. 
update habitante set nome='Lucas Frutuoso'
where idpessoa=20
-- Já que cozinhar é um de meus passatempos, por que não encontrar um padeiro para o qual eu possa trabalhar? (Dica: Liste todos os padeiros usando 'ORDER BY ouro' para ordenar os resultados. 'ORDER BY ouro DESC' é ainda melhor porque o padeiro mais rico ficará no topo.)
-- Já que cozinhar é um de meus passatempos, por que não encontrar um padeiro para o qual eu possa trabalhar? (Dica: Liste todos os padeiros usando 'ORDER BY ouro' para ordenar os resultados. 'ORDER BY ouro DESC' é ainda melhor porque o padeiro mais rico ficará no topo.)
select * habitante
where trabalho='padeiro'
order by nome desc
select * from habitante
where trabalho='padeiro'
order by nome desc
-- Olá, você de novo! Então, Lucas Frutuoso é seu nome. Vi que você quer trabalhar como padeiro? Tudo bem! Você receberá 1 de ouro para cada 100 pãezinhos.
-- Olá, você de novo! Então, Lucas Frutuoso é seu nome. Vi que você quer trabalhar como padeiro? Tudo bem! Você receberá 1 de ouro para cada 100 pãezinhos.
UPDATE habitante SET ouro = ouro + 100 - 150 WHERE idpessoa = 20
-- Aqui está sua nova espada Locos Frotooso! Agora você pode ir para qualquer lugar!
INSERT INTO item (item, proprietário) VALUES ('espada', 20)
-- Existe algum piloto nessa ilha, por acaso? Ele poderia me levar para casa.
select * from habitante
where trabalho='piloto'
-- Horrível, o piloto está sendo mantido em cativeiro por Dieter Sujo! Vou te mostrar um truque para descobrir o nome da vila em que Dieter Sujo mora.
-- Horrível, o piloto está sendo mantido em cativeiro por Dieter Sujo! Vou te mostrar um truque para descobrir o nome da vila em que Dieter Sujo mora.
SELECT aldeia.nome FROM aldeia, habitante WHERE aldeia.idaldeia = habitante.idaldeia AND habitante.nome = 'Dieter Sujo'
-- A expressão utilizada é chamada de junção. Ela combina a informação da tabela habitante com as informações da tabela aldeia coincidindo os valores de idaldeia.
SELECT * FROM aldeia, habitante WHERE aldeia.idaldeia = habitante.idaldeia AND habitante.idpessoa=aldeia.chefe
select * from aldeia,habitante
where aldeia.chefe=habitante.idpessoa;
select * from aldeia,habitante
where aldeia.chefe=habitante.idpessoa and aldeia.nome='Cidade Cebola'
select * from aldeia
where aldeia.nome='Cidade Cebola'
select habitante.nome from aldeia,habitante
where aldeia.chefe=habitante.idpessoa and aldeia.nome='Cidade Cebola'
-- Hm, quantos habitantes a Cidade Cebola tem?
-- Hm, quantos habitantes a Cidade Cebola tem?
SELECT COUNT(*) FROM habitante, aldeia WHERE aldeia.idaldeia = habitante.idaldeia AND aldeia.nome = 'Cidade Cebola'
-- "Olá Lucas Frutuoso, o piloto está mantido em cativeiro por Dieter Sujo na casa da irmã dele. Devo dizer quantas mulheres vivem em Cidade Cebola? Acho que não, descubra sozinho! (Dica: Mulher aparece como gênero = ""f"")"
select count(*) from habitante, aldeia WHERE aldeia.idaldeia = habitante.idaldeia AND (aldeia.nome = 'Cidade Cebola' and genero='f')
select count(*) from habitante, aldeia WHERE aldeia.idaldeia = habitante.idaldeia AND (aldeia.nome = 'Cidade Cebola' and gênero='f')
-- Só uma mulher? Qual seu nome?
-- Só uma mulher? Qual seu nome?
select count(*),habitante.nome from habitante, aldeia WHERE aldeia.idaldeia = habitante.idaldeia AND (aldeia.nome = 'Cidade Cebola' and gênero='f')
select habitante.nome from habitante, aldeia WHERE aldeia.idaldeia = habitante.idaldeia AND (aldeia.nome = 'Cidade Cebola' and gênero='f')
-- Lucas Frutuoso, se você me entregar todo o OURO da aldeia vizinha Cidade Pepino, eu libertarei o piloto. Eu vou te mostrar agora do quanto OURO estou falando.
-- Lucas Frutuoso, se você me entregar todo o OURO da aldeia vizinha Cidade Pepino, eu libertarei o piloto. Eu vou te mostrar agora do quanto OURO estou falando.
SELECT SUM(habitante.ouro) FROM habitante, aldeia WHERE aldeia.idaldeia = habitante.idaldeia AND aldeia.nome = 'Cidade Pepino'
-- Ah não, somente fazer pães não resolverá meu problema. Se eu continuar trabalhando e vendendo itens no entanto, eu poderia conseguir mais ouro do que o valor de ouro dos inventários de todos os padeiros, negociantes e mercadores juntos. Quanto de ouro será que vai dar com a soma desses três tipos de trabalho?
select * from habitante
where trabalho='padeiro' and (trabalho='negociante' and trabalho='mercador)
select * from habitante
where trabalho='padeiro' and (trabalho='negociante' and trabalho='mercador')
select * from habitante
where trabalho='padeiro' or (trabalho='negociante' or trabalho='mercador')
select sum(ouro) from habitante
where trabalho='padeiro' or (trabalho='negociante' or trabalho='mercador')
-- Vamos dar uma olhada na média de ouro que as pessoas têm, dependendo de seu trabalho.
-- Vamos dar uma olhada na média de ouro que as pessoas têm, dependendo de seu trabalho.
SELECT trabalho, SUM(habitante.ouro), AVG(habitante.ouro) FROM habitante GROUP BY trabalho ORDER BY AVG(habitante.ouro)
-- Muito interessante, por alguma razão, açougueiros possuem a maior quantia de ouro. Quanto ouro habitantes diferentes tem em média, dependendo de seu status (amigável,...)?
SELECT trabalho, SUM(habitante.ouro), AVG(habitante.ouro) FROM habitante 
where status='amigavel'
GROUP BY trabalho ORDER BY AVG(habitante.ouro)
SELECT trabalho, SUM(habitante.ouro), AVG(habitante.ouro) FROM habitante 
where status='amigavel'
GROUP BY trabalho ORDER BY AVG(habitante.ouro)
SELECT trabalho, SUM(habitante.ouro), AVG(habitante.ouro) FROM habitante 
where status='amigavel'
GROUP BY status ORDER BY AVG(habitante.ouro)

SELECT AVG(habitante.ouro) FROM habitante 
GROUP BY status ORDER BY AVG(habitante.ouro)

SELECT habitante.nome AVG(habitante.ouro) FROM habitante 
GROUP BY status ORDER BY AVG(habitante.ouro)

SELECT habitante.nome AVG(habitante.ouro) FROM habitante 
GROUP BY status
SELECT habitante.nome,AVG(habitante.ouro) FROM habitante 
GROUP BY status
SELECT nome,trabalho,AVG(habitante.ouro) FROM habitante GROUP BY status ORDER BY AVG(habitante.ouro)
SELECT nome,trabalho,AVG(habitante.ouro) FROM habitante GROUP BY status 
SELECT nome,trabalho,AVG(habitante.ouro) FROM habitante 
SELECT * FROM habitante 
SELECT avg(habitante.ouro) FROM habitante 
SELECT sum(habitante.ouro),avg(habitante.ouro) FROM habitante 
SELECT sum(habitante.ouro),avg(habitante.ouro) FROM habitante
group by trabalho
SELECT sum(habitante.ouro),avg(habitante.ouro) FROM habitante
group by status
SELECT nome,sum(habitante.ouro),avg(habitante.ouro) FROM habitante
group by status
SELECT nome,sum(habitante.ouro),avg(habitante.ouro) FROM habitante
group by trabalho and status
SELECT nome,sum(habitante.ouro),avg(habitante.ouro) FROM habitante
group by habitante
SELECT nome,sum(habitante.ouro),avg(habitante.ouro) FROM habitante
group by habitante.ouro
SELECT trabalho,status, SUM(habitante.ouro), AVG(habitante.ouro) FROM habitante GROUP BY trabalho ORDER BY AVG(habitante.ouro)
SELECT status, SUM(habitante.ouro), AVG(habitante.ouro) FROM habitante GROUP BY trabalho ORDER BY AVG(habitante.ouro)
SELECT status, SUM(habitante.ouro), AVG(habitante.ouro) FROM habitante GROUP BY status ORDER BY AVG(habitante.ouro)
SELECT status,  AVG(habitante.ouro) FROM habitante GROUP BY status ORDER BY AVG(habitante.ouro)
-- Ou eu poderia também apenas ir em frente e assassinar Dieter Sujo com minha espada.
-- Ou eu poderia também apenas ir em frente e assassinar Dieter Sujo com minha espada.
DELETE FROM habitante WHERE nome = 'Dieter Sujo'
-- Heeeei! Agora eu estou muito brava! O que fará a seguir, Lucas Frutuoso?
-- Heeeei! Agora eu estou muito brava! O que fará a seguir, Lucas Frutuoso?
-- Heeeei! Agora eu estou muito brava! O que fará a seguir, Lucas Frutuoso?
-- Heeeei! Agora eu estou muito brava! O que fará a seguir, Lucas Frutuoso?
delete from habitante where status='maldoso'
-- Isso! Agora eu liberto o piloto!
-- Isso! Agora eu liberto o piloto!
select * from habitante
select status from habitante

select distinct status from habitante

select status from habitante
where status='sequestrado'
select * from habitante
where status='sequestrado'

update habitante set status='amigável'
where idpessoa=8;
-- Obrigado por me libertar, Lucas Frutuoso! Eu vou te levar para casa!
-- Obrigado por me libertar, Lucas Frutuoso! Eu vou te levar para casa!
UPDATE habitante SET status = 'emigrado' WHERE idpessoa = 20
