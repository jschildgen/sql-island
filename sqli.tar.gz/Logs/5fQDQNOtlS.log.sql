-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT liste FROM bewohner
SELECT geschlecht FROM bewohner
SELECT beruf FROM bewohner
SELECT gold FROM bewohner
SELECT status FROM bewohner
SELECT name FROM dorf
SELECT gegenstand FROM besitzer
SELECT gegenstand FROM gegenstand
SELECT besitzer FROM gegenstand
