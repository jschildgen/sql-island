i
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select * from 
select * from bewohner
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
select * from bewohner where status friedlich
select * from bewohner where status  = 'friedlich'
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
select * from bewohner where beruf  = 'Waffenschmied'
select * from bewohner where beruf = 'Waffenschmied'
select * from bewohner where status  = 'friedlich' where beruf = 'Waffenschmied'
select * from bewohner where status  = 'friedlich' 
where beruf = 'Waffenschmied'
select * from bewohner where status  = 'friedlich' 
AND beruf = 'Waffenschmied'
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
select * from bewohner where status  = 'friedlich' 
LIKE '%schmied'
select * from bewohner where status  = 'friedlich' and
LIKE '%schmied'
select * from bewohner where status  = 'friedlich
and '%schmied'
select * from bewohner where status  = 'friedlich
and = '%schmied'
select * from bewohner where status  = 'friedlich
and = %schmied
select * from bewohner where status  = 'friedlich
and  %schmied
select * from bewohner where status  = 'friedlich
Like %schmied
select * from bewohner where status  = 'friedlich'
Like '%schmied'
select * from bewohner where status = 'friedlich'
Like '%schmied'
select * from bewohner where status = 'friedlich' and beruf 
Like '%schmied'
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
select * from bewohner where status = 'friedlich' and beruf 
Like '%schmied'

INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
select * from bewohner where status = 'friedlich' and beruf 
Like '%schmied'

INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder')
select * from bewohner where status = 'friedlich' and beruf 
Like '%schmied'

INSERT INTO bewohner (name)
select * from bewohner where status = 'friedlich' and beruf 
Like '%schmied'


select * from bewohner where status = 'friedlich' and beruf 
Like '%schmied'
Der * in 'bewohnernr'

select * from bewohner where status = 'friedlich' and beruf 
Like '%schmied' and Der * in 'bewohnernr'

select * from bewohner where status = 'friedlich' and beruf 
Like '%schmied' and Der * 'bewohnernr'

select * from  Der * 'bewohnernr'

select * from  Der * in 'bewohnernr'

select * from bewohner where status = 'friedlich' and beruf 
Like '%schmied' and Der * in 'bewohnernr'

