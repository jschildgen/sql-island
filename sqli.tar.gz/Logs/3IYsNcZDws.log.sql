-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select from bewohner 

select*from Bewohner 

select * from Bewohner 

-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
select * from Bewohner 
select * from Bewohne Metzger
select * from Bewohner 
select * from Bewohne * Metzger
select * from Bewohner 
select * from Bewohne = 'Metzger'
select * from Bewohner 
select * from Bewohner = 'Metzger'
select * from Bewohner 
select * from Bewohner ='Metzger'
select * from Bewohner 
  select * from Bewohner ='Metzger'
select * from Bewohner 
  select * from Bewohner 'Metzger'
select * from Bewohner 
  select * from Bewohner 'Metzger' Erich Rasenkopf
  
select * from Bewohner 
  select * from Bewohner, Erich Rasenkopf, 'Metzger'
  
select * from Bewohner 
  select * from Bewohner where beruf Metzger
  
select * from Bewohner 
  select * from Bewohner where beruf = 'Metzger'
  
select * from Bewohner 
  select * from Bewohner where beruf= 'Metzger'
  
select * from Bewohner 
  select * from Bewohner where beruf ='Metzger'
  
select * from Bewohner 
  Bewohner where beruf = 'Metzger'
  
select * from Bewohner 
  Bewohner where beruf = 'metzger'
  
select * from Bewohner 
  Bewohner where beruf = 'metzger17'
  
select * from Bewohner 
  Bewohner where beruf = 'Metzger17'
  
select * from Bewohner 
  Bewohner where beruf = 'Metzger 17'
  
select * from Bewohner 
  Bewohner where beruf = 'Metzger'
  
select * from Bewohner 
  Bewohner where beruf = 'Metzger'
  
select * from Bewohner 
   where beruf = 'Metzger'
  
select * from Bewohner 
    where beruf = 'Metzger'
  
select * from Bewohner 
    where beruf = 'metzger'
  
select * from Bewohner 
where beruf = 'metzger'
  
select * from Bewohner
where beruf = 'metzger'
  
select * from Bewohner where beruf = 'metzger'
  
select * from Bewohner 
  where beruf = 'metzger'
  select '17'
  
select * from Bewohner 
  where beruf = 'metzger' 
  
select * from Bewohner 
  WHERE beruf = 'metzger' 
  
select * from Bewohner 
  WHERE beruf ='metzger' 
  
select * from Bewohner WHERE beruf ='metzger' 
  
select * from Bewohner WHERE beruf ='Metzger' 
  
select * from Bewohner WHERE status ='friedlich' 
  
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
select * from Bewohner WHERE status ='friedlich' where Beruf ='Waffenschmied'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied'
  
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' Like '%schmiedt'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' Like '%schmied'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' and Like '%schmied'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' and beruf LIKE '%schmied'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' and Beruf LIKE '%schmied'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' and Beruf LIKE '%schmied' status ='friedlich'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' and Beruf = LIKE '%schmied' status ='friedlich'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' and Beruf =LIKE'%schmied' status ='friedlich'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' and Beruf =LIKE '%schmied'and  status ='friedlich'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' and Beruf =LIKE'%schmied'and  status ='friedlich'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' and Beruf ='LIKE%schmied'and  status ='friedlich'
  
select * from Bewohner WHERE status ='friedlich' and Beruf ='Waffenschmied' and Beruf ='Like%schmied'and  status ='friedlich'
  
select * from Bewohner WHERE beruf LIKE '%schmied' and status ='friedlich'
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
select bewohnernr  From Bewohner where Name ='Fremder' 
-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
