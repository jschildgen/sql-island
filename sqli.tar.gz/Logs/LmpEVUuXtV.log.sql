-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT * FROM Bewohner;

-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT status FROM Bewohner;

SELECT name,status FROM Bewohner;

SELECT name FROM Bewohner WHERE status = 'boese';

SELECT name FROM Bewohner WHERE status = 'friedlich';

SELECT name, status FROM Bewohner WHERE status = 'friedlich';

SELECT name FROM Bewohner WHERE status = 'friedlich';

SELECT * FROM Bewohner WHERE status = 'friedlich';

-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Schmied';

SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf = 'Waffenschmied';

-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
SELECT * FROM Bewohner WHERE status = 'friedlich' AND beruf like '%schmied';

-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
SELECT bewohnernr FROM Bewohner;

SELECT bewohnernr FROM Bewohner WHERE name = 'me';

SELECT bewohnernr FROM Bewohner WHERE name = 'Arthur Schneiderpaule';

SELECT bewohnernr FROM Bewohner WHERE gold = 0;

-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
SELECT gegenstand FROM gegenstand WHERE besitzer = 'Ernst Peng';

SELECT gold FROM Bewohner WHERE BewohnerID = 0;

SELECT gold FROM Bewohner WHERE Bewohnernr = 0;

SELECT gold FROM Bewohner WHERE Bewohnernr = 20;

-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
SELECT gegenstand FROM Gegenstand WHERE besitzer IS NULL;
SELECT * FROM Gegenstand WHERE besitzer IS NULL;
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = 'Kaffeetasse'
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
UPDATE gegenstand SET besitzer = 20;
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand like '%';
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand != 'afaf';
UPDATE gegenstand SET * besitzer = 20;
UPDATE * SET  besitzer = 20;
UPDATE Gegenstand SET besitzer = 20 WHERE gegenstand = *
UPDATE Gegenstand SET besitzer = 20 WHERE gegenstand like '_%';
UPDATE Gegenstand SET besitzer = 20 WHERE besitzer IS NULL;
UPDATE gegenstand SET besitzer = 20 WHERE besitzer IS NULL;
UPDATE GEGENSTAND SET besitzer = 20 WHERE besitzer IS NULL;
UPDATE GEGENSTAND SET besitzer = 20 WHERE besitzer IS NULL;
UPDATE GEGENSTAND SET besitzer = 210 WHERE besitzer IS NULL;
