-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT Gurkendorf

SELECT Gurkendorf dorf

SELECT *Gurkendorf FROM DORF

SELECT *1 FROM dorf Gurkendorf


SELECT *1 FROM dorf



SELECT *1 FROM dorfnr



SELECT *1 FROM Gurkendorf



SELECT Bewohnernr FROM Gurkendorf



SELECT BEWOHNER FROM Gurkendorf



SELECT BEWOHNER



SELECT BEWOHNER



SELECT BEWOHNER



SELECT BEWOHNER



SELECT BEWOHNER



SELECT BEWOHNER



SELECT BEWOHNER



SELECT BEWOHNER



SELECT BEWOHNER



SELECT BEWOHNER FROM  



SELECT *from bewohner

-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
SELECT * FROM bewohner WHERE beruf = 'Metzger'
SELECT *from bewohner

