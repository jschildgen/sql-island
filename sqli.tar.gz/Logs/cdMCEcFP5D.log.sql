select * from inhabitant where (job='dealer'or job='businessman')and state='friendly'
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select * from inhabitant where (job='dealer'or job='businessman')and state='friendly'
select * from inhabitant where (job = 'dealer' or job= 'businessman')and state='friendly'
select * from inhabitant where (job = 'dealer' or job= 'businessman') and state='friendly'
select * from inhabitant where (job = 'dealer' or job= 'businessman') and state = 'friendly'
