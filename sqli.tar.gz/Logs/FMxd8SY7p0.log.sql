-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
tables;
select * from inhabitant
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
SELECT * FROM inhabitant WHERE job = 'butcher'
-- There you are! Enjoy your meal! But take care of yourself. As long as you are unarmed, stay away from villains. Not everyone on this island is friendly.
select * from inhabitant where state = 'friendly'
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
select * from inhabitant where job = 'weaponsmith' andstate = 'friendly'
select * from inhabitant where job = 'weaponsmith' and state = 'friendly'
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
select * from inhabitant where job = '%smith' and state = 'friendly'
select * from inhabitant where job like '%smith' and state = 'friendly'
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
INSERT INTO inhabitant (name, villageid, gender, job, gold, state) VALUES ('Stranger', 1, '?', '?', 0, '?')
-- No need to call me stranger! What's my personid? (Hint: In former queries, the * stands for: all columns. Instead of the star, you can also address one or more columns (seperated by a comma) and you will only get the columns you need.)
select personid from inhabitant where name = 'Stranger';
-- Hi Ernest! How much is a sword?
-- Hi Ernest! How much is a sword?
select gold from inhabitant where name = 'Stranger';
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
select * from item where owner is null
-- Yay, a coffee cup. Let's collect it!
-- Yay, a coffee cup. Let's collect it!
UPDATE item SET owner = 20 WHERE item = 'coffee cup'
-- Do you know a trick how to collect all the ownerless items?
update item set oner = 20 where owner is null
update item set owner = 20 where owner is null
-- Now list all of the items I have!
-- Now list all of the items I have!
select * from item where owner = 20
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
select * from inhabitant where job ='merchant' or job = 'dealer'
select * from inhabitant where (job ='merchant' or job = 'dealer') and state = 'friendly'
-- I'd like to get the ring and the teapot. The rest is nothing but scrap. Please give me the two items. My personid is 15.
-- I'd like to get the ring and the teapot. The rest is nothing but scrap. Please give me the two items. My personid is 15.
update item set owner = 15 where item = 'ring' and owner = 20
update item set owner = 15 where (item = 'ring' or item = 'teapot') and owner = 20
-- Here, some gold!
-- Here, some gold!
UPDATE inhabitant SET gold = gold + 120 WHERE personid = 20
-- Unfortunately, that's not enough gold to buy a sword. Seems like I do have to work after all. Maybe it's not a bad idea to change my name from Stranger to my real name before I will apply for a job.
update inhabitant set name = "Jake Heimark" where personid = 20 
-- Since baking is one of my hobbies, why not find a baker who I can work for? (Hint: List all bakers and use 'ORDER BY gold' to sort the results. 'ORDER BY gold DESC' is even better because then the richest baker is on top.)
-- Since baking is one of my hobbies, why not find a baker who I can work for? (Hint: List all bakers and use 'ORDER BY gold' to sort the results. 'ORDER BY gold DESC' is even better because then the richest baker is on top.)
select * from inhabitant where job = 'baker' order by gold DESC
-- Hi, you again! So, Jake Heimark is your name. I saw you want to work as a baker? Okay! You will be paid 1 gold for 100 bread rolls.
-- Hi, you again! So, Jake Heimark is your name. I saw you want to work as a baker? Okay! You will be paid 1 gold for 100 bread rolls.
UPDATE inhabitant SET gold = gold + 100 - 150 WHERE personid = 20
-- Here's your new sword, Joko Hoomork! Now you can go everywhere.
INSERT INTO item (item, owner) VALUES ('sword', 20)
-- Is there a pilot on this island by any chance? He could fly me home.
select * from inhabitant where job like '%pilot' and state = 'friendly'
select * from inhabitant where job = 'pilot' and state = 'friendly'
select * from inhabitant where job = 'pilot'
-- Horrible, the pilot is held captive by Dirty Dieter! I will show you a trick how to find out the name of the village where Dirty Dieter lives.
-- Horrible, the pilot is held captive by Dirty Dieter! I will show you a trick how to find out the name of the village where Dirty Dieter lives.
SELECT village.name FROM village, inhabitant WHERE village.villageid = inhabitant.villageid AND inhabitant.name = 'Dirty Dieter'
-- The expression presented here is called a join. It combines the information of the inhabitant table with information of the village table by matching villageid values.
select * from inhabitant where inhabitant.personid = village.chief and village.name = 'Onionville"
select * from inhabitant where inhabitant.personid = village.chief and village.name = 'Onionville'
select * from inhabitant where inhabitant.personid = village.chiefid and village.name = 'Onionville'
select * from inhabitant where village.name = 'Onionville' and inhabitant.personid = village.chief
select * from inhabitant, village where village.name = 'Onionville' and inhabitant.personid = village.chief
select inhabitant.name from inhabitant, village where village.name = 'Onionville' and inhabitant.personid = village.chief
-- Um, how many inhabitants does Onionville have?
-- Um, how many inhabitants does Onionville have?
SELECT COUNT(*) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Onionville'
-- Hello Jake Heimark, the pilot is held captive by Dirty Dieter in his sister's house. Shall I tell you how many women there are in Onionville? Nah, you can figure it out by yourself! (Hint: Women show up as gender = 'f')
select count(*) from inhabitant, village where village.villageid = inhabitant.villageid AND village.name = 'Onionville' AND inhabitant.gender = 'f'
-- Oh, only one woman. What's her name?
-- Oh, only one woman. What's her name?
select inhabitant.name from inhabitant, village where village.villageid = inhabitant.villageid AND village.name = 'Onionville' AND inhabitant.gender = 'f'
-- Jake Heimark, if you hand me over the entire property of our nearby village Cucumbertown, I will release the pilot. I will show you now what this property consists of.
-- Jake Heimark, if you hand me over the entire property of our nearby village Cucumbertown, I will release the pilot. I will show you now what this property consists of.
SELECT SUM(inhabitant.gold) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Cucumbertown'
-- Oh no, baking bread alone can't solve my problems. If I continue working and selling items though, I could earn more gold than the worth of gold inventories of all bakers, dealers and merchants together. How much gold is that?
select sum(gold) from inhabitant where job = 'baker' or job = 'dealer' or job = 'merchant'
-- Let's have a look at how much average gold people own, depending on their job.
-- Let's have a look at how much average gold people own, depending on their job.
SELECT job, SUM(inhabitant.gold), AVG(inhabitant.gold) FROM inhabitant GROUP BY job ORDER BY AVG(inhabitant.gold)
-- Very interesting: For some reason, butchers own the most gold. How much gold do different inhabitants have on average, depending on their state (friendly, ...)?
select avg(gold), state from inhabitant group by state
select avg(gold), state from inhabitant group by state order by avg
select avg(gold), state from inhabitant group by state order by avg(gold)
select sum(gold), state from inhabitant group by state order by sum(gold)
select avg(gold), state from inhabitant group by state order by avg(gold)
select sum(gold), avg(gold), state from inhabitant group by state order by avg(gold)
select avg(inhabitant.gold), state from inhabitant group by state order by avg(gold)
select avg(inhabitant.gold), state from inhabitant group by state order by avg(inhabitant.gold)
select job, avg(inhabitant.gold), state from inhabitant group by state order by avg(inhabitant.gold)
select avg(inhabitant.gold), state from inhabitant group by inhabitant.state order by avg(inhabitant.gold)
select avg(inhabitant.gold), state from inhabitant group by inhabitant.state
select state, avg(inhabitant.gold) from inhabitant group by inhabitant.state
-- Or I might as well go ahead and just kill Dirty Dieter with my sword!
-- Or I might as well go ahead and just kill Dirty Dieter with my sword!
DELETE FROM inhabitant WHERE name = 'Dirty Dieter'
-- Heeeey! Now I'm very angry! What will you do next, Jake Heimark?
delete from inhabitant where name like '%Diane'
-- Yeah! Now I release the pilot!
-- Yeah! Now I release the pilot!
update state = 'friendly' from inhabitant where state = 'kidnapped'
update inhabitant set state =
'friendly' where state = 'kidnapped'
-- Thank's for releasing me, Jake Heimark! I will fly you home!
-- Thank's for releasing me, Jake Heimark! I will fly you home!
UPDATE inhabitant SET state = 'emigrated' WHERE personid = 20
