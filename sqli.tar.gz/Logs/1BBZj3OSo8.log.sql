-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
Select*From dorf Affenstadt
Select*From dorfnr 1 
Select*From bewohner

Select*From Bewohner

Select*From Bewohner *From Affenstadt

Select*From Bewohner 


Select*From dorf


Select * From Bewohner


-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
Select * From Bewohner Where status = friedlich


Select * From Bewohner Where status = `friedlich`


Select * From Bewohner Where status=friedlich


Select * From Bewohner Where status=


Select * From Bewohner Where status=friedlich


Select * From Bewohner Where = friedlich


Select * From Bewohner Where=friedlich


Select * From Bewohner Where status= "friedlich"


-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
Select * From Bewohner Where status= "friedlich" And beruf= "Waffenschmied"


-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
Select * From Bewohner Where status= "friedlich" And beruf= "%"schmied"


Select * From Bewohner Where status= "friedlich" And beruf= "%schmied"


Select * From Bewohner Where status= "friedlich" And beruf= LIKE "%schmied"


Select * From Bewohner Where status= "friedlich" And beruf LIKE "%schmied"


-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
Select bewohnernr From


Select bewohnernr From Affenstadt


Select bewohnernr From dorf



INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ("Lennart Voß", "2", "m", "Baecker", "300", "boese")



INSERT INTO Lennart Voß beruf= "Baecker"



INSERT INTO "Lennart Voß" Where beruf= "Baecker"



Select "Lennart Voß" From beruf= "Baecker"



Select "Lennart Voß" From beruf = "Baecker"



Select bewohnernr From Bewohner Where name= "Fremder"



-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
Select gold From bewohner Where name= "Fremder"



-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
Select gold From bewohner Where besitzer IS NULL



Select gold From bewohner Where=besitzer IS NULL



Select gold From bewohner Where besitzer = IS NULL



Select gold From bewohner Where besitzer= IS NULL



Select gold From bewohner Where besitzer= NULL



Select gold From bewohner Where "IS NULL"



Select*From bewohner Where "IS NULL"



Select bewohner Where "IS NULL"



Select  Where "IS NULL"



Select * From gegenstand Where besitzer IS NULL



-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = 'Kaffeetasse'
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
Select * From gegenstand SET besitzer = 20 Where gegenstand = "Kaffeetasse"



Select * From gegenstand Set besitzer = 20 Where gegenstand = "Kaffeetasse"



Select * From gegenstand Set besitzer = Where gegenstand = "Kaffeetasse"



Select * From gegenstand Set besitzer = Where gegenstand = "Teekanne"



Select * From gegenstand Set besitzer 20 = Where gegenstand = "Kaffeetasse"



Select * From gegenstand Set besitzer = Where gegenstand = "Kaffeetasse"



Select * From gegenstand =20 Where gegenstand = "Kaffeetasse"



Select * From gegenstand = 20 Where gegenstand = "Kaffeetasse"



Select * From gegenstand= 20 Where gegenstand = "Kaffeetasse"



Select * From gegenstand= 20 Where gegenstand= "Kaffeetasse"



Select * From besitzer= 20 Where gegenstand= "Kaffeetasse"



