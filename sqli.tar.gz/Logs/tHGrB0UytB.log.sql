-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT*FROM DORF
SELECT * FROM DORF
SELECT * FROM Bewohner
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT * FROM bewohner where status = 'friedlich'
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
SELECT * FROM bewohner where beruf = 'schmied' and status = 'friedlich'
SELECT * FROM bewohner where beruf = 'schmied' and = 'friedlich'
SELECT * FROM bewohner where beruf = 'schmied' and 'friedlich'
SELECT * FROM bewohner where beruf = 'schmied' and where status = 'friedlich'
SELECT * FROM bewohner where beruf = 'schmied' and status = 'friedlich'
SELECT * FROM bewohner where beruf = 'Schmied' and status = 'friedlich'
SELECT * FROM bewohner where beruf = 'Schmied' and status = 'friedlich'
SELECT * FROM bewohner where beruf = 'Waffenschmied' and status = 'friedlich'
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
SELECT * FROM bewohner where beruf = '%schmied' and status = 'friedlich'
SELECT * FROM bewohner where beruf = '%Schmied' and status = 'friedlich'
SELECT * FROM bewohner where beruf LIKE = '%schmied' and status = 'friedlich'
SELECT * FROM bewohner where beruf LIKE '%schmied' and status = 'friedlich'
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
INSERT INTO bewohner (Til Lit, 666, m, Influencer, 4000, friedlich) VALUES ('Fremder', 1, '?', '?', 0, '?')
INSERT INTO bewohner (Til Lit, 666, m, Influencer, 4000, friedlich)
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Til Lit', 1, '?', '?', 4000, '?'
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Til Lit', 1, '?', '?', 4000, '?')
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Til Lit', 1, '?', '?', 0, '?')
INSERT INTO GEGENSTAND
INSERT INTO bewohner where dorfnr = '1'
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
