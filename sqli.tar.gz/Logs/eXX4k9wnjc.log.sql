SELECT COUNT(*)FROM bewohner, dorf WHERE dorf.dorfnr = bewohner.dorfnr AND bewohner.geschlecht = "w"


-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
