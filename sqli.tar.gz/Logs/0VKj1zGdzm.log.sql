-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select dorfnr 1
select dorf 1
select bewohner

select dorf(dorfnr)
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select

-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
