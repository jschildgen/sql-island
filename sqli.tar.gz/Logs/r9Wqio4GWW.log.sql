-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
select*
from dorf
select *
from dorf
select *
from bewohner
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
select *
from bewohner
where status = "friedlich"
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
select *
from bewohner
where status = "friedlich" AND "Waffenschmied"
select *
from bewohner
where status = "friedlich" AND beruf = "Waffenschmied"
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
select *
from bewohner
where status = "friedlich" AND beruf LIKE "%schmied"
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
SELECT bewohnernr,name
FROM bewohner
SELECT bewohnernr,name
FROM bewohner
where name = "Fremder"
SELECT bewohnernr
FROM bewohner
where name = "Fremder"
-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
SELECT gold
FROM bewohner
where name = "Fremder"
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
SELECT gegenstand
FROM gegenstand
where besitzer = "NULL"
SELECT gegenstand
FROM gegenstand
where besitzer "IS NULL"
SELECT gegenstand
FROM gegenstand
where besitzer IS NULL
SELECT gegenstand
FROM Gegenstand
where besitzer IS NULL
SELECT gegenstand
FROM Gegenstand
where besitzer IS NULL
SELECT *
FROM Gegenstand
where besitzer IS NULL
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = 'Kaffeetasse'
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
UPDATE *
Set besitzer=20
where gegenstand IS NULL
UPDATE gegenstand
Set besitzer=20
where gegenstand IS NULL
UPDATE *
Set besitzer=20
where gegenstand IS NULL
UPDATE besitzer
Set besitzer=20
where gegenstand IS NULL
UPDATE besitzer
Set besitzer=20
where gegenstand IS NULL
UPDATE Gegenstand
Set besitzer=20
where gegenstand IS NULL
UPDATE Gegenstand
Set besitzer=20
where besitzer IS NULL
-- Jawoll! Welche Gegenstände besitze ich nun?
-- Jawoll! Welche Gegenstände besitze ich nun?
Select*
from Gegenstand
where besitzer = 20
Select *
from Gegenstand
where besitzer = 20
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
Select *
from Bewohner
where status = "friedlich" beruf = "Haendler" OR "Kaufmann" 
Select *
from Bewohner
where status = "friedlich" , beruf = "Haendler" OR "Kaufmann" 
Select *
from Bewohner
where status = "friedlich" beruf = "Haendler" OR "Kaufmann" 
Select *
from Bewohner
where status = "friedlich" AND (beruf = "Haendler" OR "Kaufmann")
Select *
from Bewohner
where status = "friedlich" AND(beruf = "Haendler" OR "Kaufmann")
Select *
from Bewohner
where status = "friedlich" AND(beruf = "Haendler" OR "Kaufmann")
