-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
select * from inhabitant
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
SELECT * FROM inhabitant WHERE job = 'butcher'
-- There you are! Enjoy your meal! But take care of yourself. As long as you are unarmed, stay away from villains. Not everyone on this island is friendly.
-- There you are! Enjoy your meal! But take care of yourself. As long as you are unarmed, stay away from villains. Not everyone on this island is friendly.
select * from inhabitant where state = 'friendly'
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
select * from inhabitant where state = 'friendly' and 'weaponsmith'
select * from inhabitant where state = 'friendly' and state = 'weaponsmith'
select * from inhabitant where state = 'friendly' and job = 'weaponsmith'
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
select * from inhabitant where state = 'friendly' and job LIKE '%smith'
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
INSERT INTO inhabitant (name, villageid, gender, job, gold, state) VALUES ('Stranger', 1, '?', '?', 0, '?')
-- No need to call me stranger! What's my personid? (Hint: In former queries, the * stands for: all columns. Instead of the star, you can also address one or more columns (seperated by a comma) and you will only get the columns you need.)
select personid from inhabitant where name = 'Stranger'
-- Hi Ernest! How much is a sword?
-- Hi Ernest! How much is a sword?
select gold from inhabitant where personid = 20
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
select * from item where owner is null
-- Yay, a coffee cup. Let's collect it!
-- Yay, a coffee cup. Let's collect it!
UPDATE item SET owner = 20 WHERE item = 'coffee cup'
-- Do you know a trick how to collect all the ownerless items?
UPDATE item SET owner = 20 WHERE item is null
UPDATE item SET owner = 20 WHERE owner is null
-- Now list all of the items I have!
-- Now list all of the items I have!
select * from item where owner = 20
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
select * from inhabitant where state = 'friendly' and job = 'dealer' or job = 'merchant'
-- I'd like to get the ring and the teapot. The rest is nothing but scrap. Please give me the two items. My personid is 15.
-- I'd like to get the ring and the teapot. The rest is nothing but scrap. Please give me the two items. My personid is 15.
UPDATE item SET owner = 15 WHERE item = 'teapot' and item = 'ring'
select * from item
UPDATE item SET owner = 15 
    WHERE item = 'ring' 
            and 
          item = 'teapot'
UPDATE item SET owner = 15 
    WHERE item = 'ring' 
           
select * from item
UPDATE item SET owner = 15 
    WHERE item when('ring', 'teapot')
UPDATE item SET owner = 15 
    WHERE item IN('ring', 'teapot')
-- Here, some gold!
-- Here, some gold!
UPDATE inhabitant SET gold = gold + 120 WHERE personid = 20
-- Unfortunately, that's not enough gold to buy a sword. Seems like I do have to work after all. Maybe it's not a bad idea to change my name from Stranger to my real name before I will apply for a job.
UPDATE inhabitant SET name = 'Felipe' WHERE personid = 20
-- Since baking is one of my hobbies, why not find a baker who I can work for? (Hint: List all bakers and use 'ORDER BY gold' to sort the results. 'ORDER BY gold DESC' is even better because then the richest baker is on top.)
-- Since baking is one of my hobbies, why not find a baker who I can work for? (Hint: List all bakers and use 'ORDER BY gold' to sort the results. 'ORDER BY gold DESC' is even better because then the richest baker is on top.)
select * from inhabitant where job = 'baker' order by gold
-- Hi, you again! So, Felipe is your name. I saw you want to work as a baker? Okay! You will be paid 1 gold for 100 bread rolls.
-- Hi, you again! So, Felipe is your name. I saw you want to work as a baker? Okay! You will be paid 1 gold for 100 bread rolls.
UPDATE inhabitant SET gold = gold + 100 - 150 WHERE personid = 20
-- Here's your new sword, Folopo! Now you can go everywhere.
INSERT INTO item (item, owner) VALUES ('sword', 20)
-- Is there a pilot on this island by any chance? He could fly me home.
select * from inhabitant where job = 'baker' order by gold
select * from inhabitant where job = 'pilot'
-- Horrible, the pilot is held captive by Dirty Dieter! I will show you a trick how to find out the name of the village where Dirty Dieter lives.
-- Horrible, the pilot is held captive by Dirty Dieter! I will show you a trick how to find out the name of the village where Dirty Dieter lives.
SELECT village.name FROM village, inhabitant WHERE village.villageid = inhabitant.villageid AND inhabitant.name = 'Dirty Dieter'
-- The expression presented here is called a join. It combines the information of the inhabitant table with information of the village table by matching villageid values.
-- The expression presented here is called a join. It combines the information of the inhabitant table with information of the village table by matching villageid values.
select * from village
select inhabitant.name, inhabitant.personid from village, inhabitant where village.chief = inhabitant.personid 
select inhabitant.name, inhabitant.personid from village, inhabitant where village.chief = inhabitant.personid and village.name = 'Onionville' 
select inhabitant.name from village, inhabitant where village.chief = inhabitant.personid and village.name = 'Onionville' 
-- Um, how many inhabitants does Onionville have?
-- Um, how many inhabitants does Onionville have?
SELECT COUNT(*) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Onionville'
-- Hello Felipe, the pilot is held captive by Dirty Dieter in his sister's house. Shall I tell you how many women there are in Onionville? Nah, you can figure it out by yourself! (Hint: Women show up as gender = 'f')
SELECT COUNT(*) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Onionville' and inhabitant.gender = 'f'
-- Oh, only one woman. What's her name?
-- Oh, only one woman. What's her name?
SELECT inhabitant.name FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Onionville' and inhabitant.gender = 'f'
-- Felipe, if you hand me over the entire property of our nearby village Cucumbertown, I will release the pilot. I will show you now what this property consists of.
-- Felipe, if you hand me over the entire property of our nearby village Cucumbertown, I will release the pilot. I will show you now what this property consists of.
SELECT SUM(inhabitant.gold) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Cucumbertown'
-- Oh no, baking bread alone can't solve my problems. If I continue working and selling items though, I could earn more gold than the worth of gold inventories of all bakers, dealers and merchants together. How much gold is that?
SELECT SUM(inhabitant.gold) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Cucumbertown' and inhabitant.job IN ('bakers', 'dealers', 'merchants')
SELECT SUM(inhabitant.gold) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Cucumbertown' and inhabitant.job = 'baker'
SELECT SUM(inhabitant.gold) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Cucumbertown' and inhabitant.job = 'baker'
select * from inhabitant
SELECT SUM(inhabitant.gold) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Cucumbertown' and inhabitant.job = 'dealer'
SELECT SUM(inhabitant.gold) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Cucumbertown' and inhabitant.job in ('dealer', 'baker')
SELECT SUM(inhabitant.gold) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Cucumbertown' and inhabitant.job = 'dealer' and inhabitant.job = 'baker' and inhabitant.job = 'merchant'
SELECT SUM(inhabitant.gold) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Cucumbertown' and inhabitant.job = 'dealer' or inhabitant.job = 'baker' or inhabitant.job = 'merchant'
SELECT SUM(inhabitant.gold) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Monkeycity' and inhabitant.job = 'dealer' or inhabitant.job = 'baker' or inhabitant.job = 'merchant'
SELECT SUM(inhabitant.gold) FROM inhabitant WHERE inhabitant.job = 'dealer' or inhabitant.job = 'baker' or inhabitant.job = 'merchant'
-- Let's have a look at how much average gold people own, depending on their job.
-- Let's have a look at how much average gold people own, depending on their job.
SELECT job, SUM(inhabitant.gold), AVG(inhabitant.gold) FROM inhabitant GROUP BY job ORDER BY AVG(inhabitant.gold)
-- Very interesting: For some reason, butchers own the most gold. How much gold do different inhabitants have on average, depending on their state (friendly, ...)?
SELECT SUM(inhabitant.gold), AVG(inhabitant.gold), state FROM inhabitant GROUP BY state ORDER BY AVG(inhabitant.gold)
SELECT AVG(inhabitant.gold), state FROM inhabitant GROUP BY state ORDER BY AVG(inhabitant.gold)
SELECT state FROM inhabitant GROUP BY state ORDER BY AVG(inhabitant.gold)
SELECT AVG(inhabitant.gold), state FROM inhabitant GROUP BY state ORDER BY state
