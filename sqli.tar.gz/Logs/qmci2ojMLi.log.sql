-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT *FROM BEWOHNER

-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT * FROM BEWOHNER WHERE status="friedlich"


-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
SELECT * FROM BEWOHNER WHERE status="friedlich" AND beruf="Waffenschmied"



-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
SELECT * FROM BEWOHNER WHERE status="friedlich" AND beruf LIKE "%schmied%"



-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
SELECT dorfnr FROM BEWOHNER WHERE name = "Fremder"




SELECT bewohnernr FROM BEWOHNER WHERE name = "Fremder"




-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
SELECT gold FROM BEWOHNER WHERE bewohnernr = 1





SELECT gold FROM BEWOHNER WHERE bewohnernr = 20






-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
SELECT * FROM GEGENSTAND WHERE GEGENSTAND = NULL






SELECT * FROM GEGENSTAND WHERE besitzeer = NULL






SELECT * FROM GEGENSTAND WHERE besitzer = NULL






SELECT * FROM GEGENSTAND WHERE besitzer IS NULL






-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = 'Kaffeetasse'
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
UPDATE gegenstand SET besitzer = 20 where besitzer IS NULL






-- Jawoll! Welche Gegenstände besitze ich nun?
-- Jawoll! Welche Gegenstände besitze ich nun?
select gegenstand FROM GEGENSTAND WHERE besitzer = 20






select * FROM GEGENSTAND WHERE besitzer = 20






-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
select * FROM BEWOHNER where beruf = "Haendler" OR beruf = "Kaufmann"






select * FROM BEWOHNER where beruf = "Haendler" OR beruf = "Kaufmann" AND status = "friedlich"






select * FROM BEWOHNER where status = "friedlich" AND beruf = "Haendler" OR beruf = "Kaufmann"






-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
UPDATE GEGENSTAND set besitzer = 15 WHERE besitzer = 20 AND gegenstand = "Teekann" OR gegenstand ="Ring"






UPDATE GEGENSTAND set besitzer = 15 WHERE besitzer = 20 AND gegenstand = "Teekanne" OR gegenstand ="Ring"






-- Hier hast du einen Haufen Gold!
-- Hier hast du einen Haufen Gold!
UPDATE bewohner SET gold = gold + 120 WHERE bewohnernr = 20
-- Leider reicht das noch nicht für ein Schwert. Dann muss ich wohl doch arbeiten. Bevor ich mich jedoch irgendwo bewerbe, sollte ich vielleicht meinen Namen von Fremder auf meinen richtigen Namen ändern, ansonsten wird mich niemand einstellen.
UPDATE BEWOHNER set name = "Jan" WHERE bewohnernr = 20






-- In meiner Freizeit backe ich gerne. Ich glaube, ich verdiene mir ein bisschen Geld als Bäcker. Zeige mir alle Bäcker. Tipp: Mit ORDER BY gold kannst du die Liste sortieren, mit ORDER BY gold DESC steht sogar der reichste Bäcker oben.
-- In meiner Freizeit backe ich gerne. Ich glaube, ich verdiene mir ein bisschen Geld als Bäcker. Zeige mir alle Bäcker. Tipp: Mit ORDER BY gold kannst du die Liste sortieren, mit ORDER BY gold DESC steht sogar der reichste Bäcker oben.
SELECT * FROM BEWOHNER WHERE beruf = "Baecker" ORDER BY gold




-- Hi, da bist du ja wieder! Soso, Jan heißt du also. Und du willst als Bäcker arbeiten? Da sag ich nicht nein. Ich zahle dir pro hundert Brötchen, die du mir bäckst, 1 Gold.
-- Hi, da bist du ja wieder! Soso, Jan heißt du also. Und du willst als Bäcker arbeiten? Da sag ich nicht nein. Ich zahle dir pro hundert Brötchen, die du mir bäckst, 1 Gold.
UPDATE bewohner SET gold = gold + 100 - 150 WHERE bewohnernr = 20
-- Hier ist dein neues Schwert, Jon! Nun kannst du überall hin!
INSERT INTO gegenstand (gegenstand, besitzer) VALUES ('Schwert', 20)
-- Gibt es auf der Insel einen Piloten? Er könnte mich nach Hause fliegen.
SELECT * FROM BEWOHNER WHERE beruf = "Pilot" ORDER BY gold




-- Es ist schrecklich! Dirty Dieter hält den Piloten gefangen! Ich verrate dir einen Trick, wie wir schnell herausfinden können, in welchem Dorf Dirty Dieter wohnt.
-- Es ist schrecklich! Dirty Dieter hält den Piloten gefangen! Ich verrate dir einen Trick, wie wir schnell herausfinden können, in welchem Dorf Dirty Dieter wohnt.
SELECT dorf.name FROM dorf, bewohner WHERE dorf.dorfnr = bewohner.dorfnr AND bewohner.name = 'Dirty Dieter'
-- Auf diese Weise kannst du das Dorf mit der Dorf-Nummer suchen, die bei Dirty Dieter im Feld dorfnr steht. Ein solch genialer Ausdruck nennt sich Verbund oder Join.
SELECT haeuptling FROM DORF Where name = "Zwiebelhausen"




SELECT * FROM DORF Where name = "Zwiebelhausen"




SELECT name FROM BEWOHNER WHERE bewohnernr = 13




-- Hm, wie viele Einwohner hat eigentlich Zwiebelhausen?
-- Hm, wie viele Einwohner hat eigentlich Zwiebelhausen?
SELECT COUNT(*) FROM bewohner, dorf WHERE dorf.dorfnr = bewohner.dorfnr AND dorf.name = 'Zwiebelhausen'
-- Hallo Jan, Dirty Dieter hält den Piloten im Haus seiner Schwester gefangen. Soll ich dir verraten, wie viele Frauen es in Zwiebelhausen gibt? Ach was, das kannst du schon selbst herausfinden! (Hinweis: Frauen erkennt man an geschlecht = 'w')
SELECT COUnT(*) FROM bewohner WHERE dorfnr = 3




SELECT COUnT(*) FROM bewohner WHERE dorfnr = 3 AND geschlecht = "w"




-- Ha, nur eine Frau. Mal schauen, wie sie heißt.
-- Ha, nur eine Frau. Mal schauen, wie sie heißt.
SELECT name FROM bewohner WHERE dorfnr = 3 AND geschlecht = "w"




-- Jan, gib mir alles Gold, was die Bewohner von unserem Nachbardorf Gurkendorf zusammen besitzen und ich lasse den Piloten frei! Du willst wissen, wie viel das ist? Ich zeige es dir!
-- Jan, gib mir alles Gold, was die Bewohner von unserem Nachbardorf Gurkendorf zusammen besitzen und ich lasse den Piloten frei! Du willst wissen, wie viel das ist? Ich zeige es dir!
SELECT SUM(bewohner.gold) FROM bewohner, dorf WHERE dorf.dorfnr = bewohner.dorfnr AND dorf.name = 'Gurkendorf'
-- So viel Gold werde ich niemals allein durch Brötchenbacken verdienen können. Ich muss mir etwas anderes einfallen lassen. Wenn ich Gegenstände verkaufe und zusätzlich noch als Bäcker arbeite, kann ich maximal so viel Gold bekommen, wie die Händler, Kaufmänner und Bäcker zusammen besitzen. Wie viel ist das?
SELECT gold FROM bewohner WHERE Beruf = "Baecker" or Beruf = "Haendler" or Beruf = "Kaufmaenner"




SELECT SUM(gold) FROM bewohner WHERE Beruf = "Baecker" or Beruf = "Haendler" or Beruf = "Kaufmaenner"




SELECT * FROM bewohner WHERE Beruf = "Baecker" or Beruf = "Haendler" or Beruf = "Kaufmaenner"




SELECT * FROM bewohner WHERE Beruf = "Baecker" or Beruf = "Haendler" or Beruf = "Kaufmaenner"




SELECT * FROM bewohner WHERE Beruf = "Baecker" or Beruf = "Haendler" or Beruf = "Kaufmaenn"




SELECT * FROM bewohner




SELECT sum(gold) FROM bewohner WHERE Beruf = "Baecker" or Beruf = "Haendler" or Beruf = "Kaufmannn"




SELECT sum(gold) FROM bewohner WHERE Beruf = "Baecker" or Beruf = "Haendler" or Beruf = "Kaufmann"




-- Schauen wir mal die gesamten sowie durchschnittlichen Goldvorräte der einzelnen Berufe an.
-- Schauen wir mal die gesamten sowie durchschnittlichen Goldvorräte der einzelnen Berufe an.
SELECT beruf, SUM(bewohner.gold), AVG(bewohner.gold) FROM bewohner GROUP BY beruf ORDER BY AVG(bewohner.gold)
-- Interessant, die Metzger haben also das meiste Gold. Warum auch immer... Wie viel Gold haben im Durchschnitt die einzelnen Bewohnergruppen je nach Status (friedlich, böse, gefangen)?
SELECT beruf, SUM(bewohner.gold), AVG(bewohner.gold) FROM bewohner GROUP BY beruf ORDER BY AVG(bewohner.gold) GROUP BY status




SELECT beruf, SUM(bewohner.gold), AVG(bewohner.gold) FROM bewohner GROUP BY beruf ORDER BY AVG(bewohner.gold) ORDER BY status




SELECT beruf, SUM(bewohner.gold), AVG(bewohner.gold) FROM bewohner GROUP BY beruf ORDER BY AVG(bewohner.gold) AND BY status




SELECT beruf, SUM(bewohner.gold), AVG(bewohner.gold) FROM bewohner GROUP BY beruf ORDER BY AVG(bewohner.gold) AND BY ORDER status




SELECT beruf, SUM(bewohner.gold), AVG(bewohner.gold) FROM bewohner GROUP BY beruf ORDER BY AVG(bewohner.gold) AND status




SELECT beruf, SUM(bewohner.gold), AVG(bewohner.gold) FROM bewohner GROUP BY beruf ORDER BY status




SELECT beruf, SUM(bewohner.gold), AVG(bewohner.gold),status FROM bewohner GROUP BY beruf ORDER BY status




SELECT  SUM(bewohner.gold), AVG(bewohner.gold),status FROM bewohner GROUP BY status




SELECT  SUM(bewohner.gold), AVG(bewohner.gold),status FROM bewohner GROUP BY status order by gold




