-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
Select from Zwiebelhausen

SELECT+FROM Zwiebelhausen

Select From Zwiebelhause

Select*From Zwiebelhausen


Select *From Zwiebelhausen


Select * From Zwiebelhausen


-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
