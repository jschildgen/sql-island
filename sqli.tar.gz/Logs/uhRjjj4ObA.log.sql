-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT*FORM bewohner
SELECT*FORM Bewohner
SELECT*Bewohner
bewohner  name  dorfnr  geschlecht  beruf  gold  status

bewohner, name, dorfnr, geschlecht, beruf, gold, status

bewohner, name, dorfnr, geschlecht, beruf, gold, status

bewohner, name, dorfnr, geschlecht, beruf, gold, status

bewohner, name, dorfnr, geschlecht, beruf, gold, status

bewohner, name, dorfnr, geschlecht, beruf, gold, status

bewohner, name, dorfnr, geschlecht, beruf, gold, status

bewohner,name,dorfnr,geschlecht,beruf,gold,status

select * form BEWOHNER

select * form  BEWOHNER

select * form  bewohner,name,dorfnr,geschlecht,beruf,gold,status

select * From BEWOHNWER

select * From BEWOHNWER

select  * From BEWOHNWER

select  *  From BEWOHNWER

SELECT * FROM BEWOHNWER

SELECT * FROM BEWOHNWER affenstadt

