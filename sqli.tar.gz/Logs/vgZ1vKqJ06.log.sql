-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
SELECT * FROM village
SELECT * FROM village
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
