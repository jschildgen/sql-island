-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.
SELECT * FROM bewohner

-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!
SELECT * FROM bewohner WHERE status = 'friedlich'

-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
SELECT * FROM bewohner WHERE status = 'friedlich' beruf = 'Waffenschmied' 

SELECT * FROM bewohner WHERE status = 'friedlich' AND beruf = 'Waffenschmied' 

-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
SELECT * FROM bewohner WHERE status = 'friedlich' AND beruf = '%schmied' 

SELECT * FROM bewohner WHERE status = 'friedlich' AND beruf = %schmied 

SELECT * FROM bewohner WHERE status = 'friedlich' AND beruf = %'schmied' 

SELECT * FROM bewohner WHERE status = 'friedlich' AND beruf = '%schmied' 

SELECT * FROM bewohner WHERE status = 'friedlich' AND beruf = '%schmied' 

SELECT * FROM bewohner WHERE status = 'friedlich' AND beruf = LIKE'%schmied' 
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
SELECT * FROM bewohner WHERE status = 'friedlich' AND beruf LIKE'%schmied
SELECT * FROM bewohner WHERE status = 'friedlich' AND beruf LIKE'%schmied'
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
Select * From bewohner where name = 'Frember'
Select * From bewohner where name = 'Fremder'
help 

 Select * From bewohner where bewohnernr = '20'

 Select * From bewohner where name = "Fremder"

 Select * From bewohnernr where name = "Fremder"

 Select bewohnernr from Bewohner where name = "Fremder"

-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
 Select gold from Bewohner where name = "Fremder"

-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
Select * From gegenstand where besitzer IS NULL.

Select * From gegenstand where besitzer = IS NULL.

Select * From gegenstand where besitzer = ISNULL.

Select * From gegenstand where besitzer IS NULL.

 Select besitzer from gegenstand 

-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
select * from gegenstand WHERE besitzer IS NULL

-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
select * from bewohner
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
select * from bewohner
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand Is null 
UPDATE gegenstand SET besitzer = 20 WHERE  besitzer Is null 
-- Jawoll! Welche Gegenstände besitze ich nun?
-- Jawoll! Welche Gegenstände besitze ich nun?
select * From gegenstand
select * From gegenstand where besitzer = '20'
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
select * From bewohner where beruf = ' Haendler' And beruf 'Kaufmann'
select * From bewohner where beruf = ' Haendler' 'Kaufmann'
select * From bewohner where beruf = ' Haendler' 
select * From bewohner 
select * From bewohner where beruf = "kaufmann"
select * From bewohner where beruf = "Kaufmann"
select * From bewohner where beruf = "Haendler"
select * From bewohner where beruf = "Haendler" or "Kaufmann"
select * From bewohner where beruf = ("Haendler" or "Kaufmann")
select * From bewohner where (beruf = "Haendler" or "Kaufmann")
select * From bewohner (where beruf = "Haendler" or "Kaufmann")
select * From bewohner where status= 'frriedlich' And (beruf = "Haendler" or beruf ="Kaufmann")
select * From bewohner where status= 'frriedlich' And (beruf = "Haendler" or beruf ="Kaufmann")
select * From bewohner where status= 'frriedlich' And beruf = "Haendler" or beruf ="Kaufmann"
select * From bewohner where status= 'frriedlich' And ( beruf = "Haendler" or beruf ="Kaufmann")
select * From bewohner where status= 'friedlich' And ( beruf = "Haendler" or beruf ="Kaufmann")
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
select * from bewohner

-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
select * Form gegenstand
select * From gegenstand
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
UPDATE gegenstand SET besitzer = 15 
-- Hier hast du einen Haufen Gold!
-- Hier hast du einen Haufen Gold!
-- Hier hast du einen Haufen Gold!
select gold from bewohner where name = "Fremder"
-- Leider reicht das noch nicht für ein Schwert. Dann muss ich wohl doch arbeiten. Bevor ich mich jedoch irgendwo bewerbe, sollte ich vielleicht meinen Namen von Fremder auf meinen richtigen Namen ändern, ansonsten wird mich niemand einstellen.
update name from bewohner where name = "Fremder" set name = "HKS"
hgn
-- Leider reicht das noch nicht für ein Schwert. Dann muss ich wohl doch arbeiten. Bevor ich mich jedoch irgendwo bewerbe, sollte ich vielleicht meinen Namen von Fremder auf meinen richtigen Namen ändern, ansonsten wird mich niemand einstellen.
select * bewohner

select * from bewohner

