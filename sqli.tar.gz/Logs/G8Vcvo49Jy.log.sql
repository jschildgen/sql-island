-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
-- Und jede Menge Bewohner gibt es hier auch. Zeige mir die Liste der Bewohner.

SELECT * FROM dorf

SELECT * FROM Affenstadt


SELECT * FROM 1


SELECT * FROM dorfnr


SELECT * FROM dorf


SELECT * FROMdorf


SELECT * FROM BEWOHNER 

-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
-- Mensch, was bin ich hungrig. Ich suche mir erst einmal einen Metzger, bei dem ich eine Scheibe Wurst schnorren kann.
SELECT * FROM bewohner WHERE beruf = 'Metzger'
-- Hier, lass es dir schmecken! Und pass bei deiner Reise gut auf, dass du dich von bösen Bewohnern fern hälst, solange du unbewaffnet bist. Denn nicht jeder hier ist friedlich!

SELECT * FROM BEWOHNER WHERE beruf = 'Metzger'


SELECT * FROM BEWOHNER WHERE beruf = Metzger


SELECT * FROM BEWOHNER WHERE beruf = 'Metzger'

SELECT * FROM BEWOHNER WHERE beruf = 'Metzger'(friedlich)

SELECT * FROM BEWOHNER(friedlich) WHERE beruf = 'Metzger'

SELECT * FROM BEWOHNER WHERE beruf = 'Metzger','friedlich'

SELECT * FROM BEWOHNER WHERE beruf = 'friedlich'

SELECT * FROM BEWOHNER WHERE status = 'friedlich'
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)
-- Früher oder später brauche ich aber ein Schwert. Lasst uns einen friedlichen Waffenschmied suchen, der mir ein Schwert schmieden kann. (Hinweis: Bedingungen im WHERE-Teil kannst du mit AND verknüpfen)

SELECT * FROM BEWOHNER WHERE status = 'friedlich' and beruf = Waffenschmied

SELECT * FROM BEWOHNER WHERE status = 'friedlich' and beruf = 'Waffenschmied'
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).
-- Hm, das sind sehr wenige. Vielleicht gibt es noch andere friedliche Schmiede, z.B. Hufschmied, Schmied, Waffenschmied, etc. Probiere beruf LIKE '%schmied', um alle Bewohner zu finden, deren Beruf mit 'schmied' endet (% ist ein Platzhalter für beliebig viele Zeichen).

SELECT * FROM BEWOHNER WHERE status = 'friedlich' and beruf like '%schmied'
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
-- Hallo Fremder, wohin des Wegs? Ich bin Paul, der Bürgermeister von Affenstadt. Ich trage dich gerne als Bewohner meines Dorfes ein.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
-- Hey, nenn mich doch nicht Fremder! Naja, egal. Wie ist eigentlich meine bewohnernr? (Tipp: Der * in den vorherigen Abfragen stand immer für 'alle Spalten'. Stattdessen kannst du aber auch einen oder mehrere mit Komma getrennte Spaltennamen angeben.
INSERT INTO bewohner (name, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
INSERT INTO bewohner (1,Paul, dorfnr, geschlecht, beruf, gold, status) VALUES ('Fremder', 1, '?', '?', 0, '?')
SELECT * FROM BEWOHNER WHERE name = 'Paul'
SELECT bewohnernr FROM bewohner WHere name= 'Fremder'
-- Hallo Ernst! Was kostet bei dir ein Schwert?
-- Hallo Ernst! Was kostet bei dir ein Schwert?
SELECT gold FROM bewohner WHere bewohnernr = '20'
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
-- Mist, ich habe ja noch gar kein Gold. Ich habe aber auch keine Lust dafür arbeiten zu gehen. Hmmm, vorhin habe ich viele Gegenstände herumliegen gesehen, die niemandem gehören. Diese Gegenstände könnte ich einsammeln und an Händler verkaufen. Liste alle Gegenstände auf, die niemandem gehören. Tipp: Herrenlose Gegenstände erkennt man an WHERE besitzer IS NULL.
SELECT * FROM gegenstand WHere besitzer IS NULL
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
-- Lasst uns die Kaffeetasse einsammeln. Eine Kaffeetasse kann man immer mal gebrauchen.
UPDATE gegenstand SET besitzer = 20 WHERE gegenstand = 'Kaffeetasse'
-- Kennst du einen Trick, wie wir alle Gegenstände auf einmal einsammeln können, die niemandem gehören?
UPDATE gegenstand SET besitzer = 20 WHERE besitzer is null
-- Jawoll! Welche Gegenstände besitze ich nun?
-- Jawoll! Welche Gegenstände besitze ich nun?
SELECT * FROM gegenstand WHere besitzer = 20

-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
-- Finde friedliche Bewohner mit dem Beruf Haendler oder Kaufmann. Eventuell möchten sie etwas von uns kaufen. (Hinweis: Achte bei AND- und OR-Verknüpfungen auf korrekte Klammerung)
SELECT * FROM bewohner where beruf = 'Haendler' or 'Kaufmann'

SELECT * FROM bewohner where beruf = 'Haendler' or 'Kaufmann' and status = 'friedlich'

SELECT * FROM bewohner where beruf = 'Haendler'and status = 'friedlich' or 'Kaufmann' and status = 'friedlich'

SELECT * FROM BEWOHNER WHERE status = 'friedlich' and beruf = ('Haendler'or'Kaufmann')
SELECT * FROM BEWOHNER WHERE status = 'friedlich' and beruf = 'Haendler'or'Kaufmann'
SELECT * FROM BEWOHNER WHERE status = 'friedlich' and (beruf = 'Haendler' or 'Kaufmann')
SELECT * FROM BEWOHNER WHERE status = 'friedlich' and beruf = ('Haendler' or 'Kaufmann')
SELECT * FROM BEWOHNER WHERE status = 'friedlich' and (beruf = 'Haendler' or beruf = 'Kaufmann')
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
-- Ich interessiere mich für den Ring und die Teekanne. Der Rest ist alles Schrott. Gib mir bitte die beiden Gegenstände. Meine Bewohnernummer ist übrigens 15.
UPDATE gegenstand SET besitzer = 15 WHERE (gegenstand = 'Ring' and gegenstand = 'Teekanne')
