-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
-- Hui, was ist passiert? Es scheint, als habe ich als einziger den Flugzeugabsturz überlebt. Gut, dass ich auf dieser Insel gelandet bin. Hier gibt es ja sogar ein paar Dörfer.
SELECT * FROM dorf
SELECT * FROM dorf
select gegenstand from bewohner, dorf where besitzer = 'w' and dorf.name = 'Zwiebelhausen'
select gegenstand from bewohner, dorf, gegenstand where besitzer = 'w' and dorf.name = 'Zwiebelhausen'
select gegenstand from bewohner, dorf, gegenstand where besitzer = 'w' and dorf.name = 'Gurkendorf'
select gegenstand from bewohner, dorf, gegenstand where besitzer = 'w' and dorf.name = 'Affenstadt'
select gegenstand from bewohner, dorf, gegenstand where besitzer = 'm' and dorf.name = 'Affenstadt'
select gegenstand from bewohner, dorf, gegenstand where besitzer = 'm' and dorf.name = 'Zwiebelhausen'
select gegenstand from bewohner, dorf, gegenstand where besitzer = 'm' and dorf.name = 'Gurkendorf'
select gegenstand from bewohner, dorf, gegenstand where besitzer = 'm' and dorf.name = 'Zwiebelhausen'
select gegenstand.gegenstand from bewohner, dorf, gegenstand where besitzer = 'm' and dorf.name = 'Zwiebelhausen'
select gegenstand.gegenstand from bewohner, dorf, gegenstand where geschlecht = 'm' and dorf.name = 'Zwiebelhausen'
select gegenstand from bewohner, dorf, gegenstand where geschlecht = 'm' and dorf.name = 'Zwiebelhausen'
select gegenstand from bewohner, dorf, gegenstand where geschlecht = 'm' and dorf.name = 'Zwiebelhausen' and bewohner.dorfnr = dorf.dorfnr
select gegenstand from bewohner, dorf, gegenstand where geschlecht = 'm' and dorf.name = 'Zwiebelhausen' and bewohner.dorfnr = dorf.dorfnr and gegenstand.besitzer = bewohner.bewohnernr
select beruf from bewohner group by dorf.dorfnr order by gold desc
select beruf from bewohner, dorf group by dorf.dorfnr order by gold desc
select beruf, dorf.name from bewohner, dorf group by dorf.dorfnr order by gold desc
select beruf, dorf.name, gold from bewohner, dorf group by dorf.dorfnr order by gold desc
select beruf, dorf.name, gold from bewohner, dorf group by dorf.dorfnr order by sum(gold) desc
select beruf, dorf.name, max(gold) from bewohner, dorf group by dorf.dorfnr order by sum(gold) desc
select beruf, dorf.name, max(gold) from bewohner, dorf group by dorf.dorfnr order by Max(gold) desc
select beruf, dorf.name from bewohner, dorf group by dorf.dorfnr order by Max(gold) desc
select beruf, dorf.name, gold from bewohner, dorf group by dorf.dorfnr order by Max(gold) desc
select beruf, dorf.name, gold from bewohner, dorf group by dorf.dorfnr order by sum(gold) desc
select beruf, dorf.name, gold from bewohner, dorf group by dorf.dorfnr order by sum(gold) desc
select beruf, dorf.name, sum(gold) from bewohner, dorf group by dorf.dorfnr order by sum(gold) desc
select beruf, dorf.name, sum(gold) from bewohner, dorf group by bewohner.dorfnr order by sum(gold) desc
select beruf, dorf.name, gold from bewohner, dorf group by bewohner.dorfnr order by sum(gold) desc
select beruf, dorf.name, sum(gold) from bewohner, dorf group by bewohner.dorfnr order by sum(gold) desc
select beruf, dorf.name, sum(gold) from bewohner, dorf group by bewohner.dorfnr order by gold desc
select beruf, dorf.name, sum(gold) from bewohner, dorf group by bewohner.dorfnr order by sum(gold) desc
select beruf, dorf.name, sum(gold) from bewohner, dorf group by bewohner.bewohnernr order by sum(gold) desc
select *, sum(gold) from bewohner, dorf group by bewohner.bewohnernr order by sum(gold) desc
select beruf, dorf.name, sum(gold) from bewohner, dorf group by bewohner.bewohnernr order by sum(gold) desc
select beruf, dorf.name, gold from bewohner, dorf group by bewohner.bewohnernr order by gold desc
