-- Ó céus, o que aconteceu? Parece que eu sou o único sobrevivente do acidente aéreo. Nossa, existem algumas aldeias nessa ilha.
SELECT * FROM aldeia
