-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
Select personid, name FROM INHABITANT
Select name FROM INHABITANT
Select * FROM INHABITANT
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
SELECT * FROM inhabitant WHERE job = 'butcher'
-- There you are! Enjoy your meal! But take care of yourself. As long as you are unarmed, stay away from villains. Not everyone on this island is friendly.
Select * FROM INHABITANT
Where state = 'friendly'
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
Select * FROM INHABITANT
Where state = 'friendly'
and
job = 'weaponsmith'
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
Select * FROM INHABITANT
Where state = 'friendly'
and
job like '%smith'
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
INSERT INTO inhabitant (name, villageid, gender, job, gold, state) VALUES ('Stranger', 1, '?', '?', 0, '?')
-- No need to call me stranger! What's my personid? (Hint: In former queries, the * stands for: all columns. Instead of the star, you can also address one or more columns (seperated by a comma) and you will only get the columns you need.)
Select personid, name from INHABITANT
Select personid, name from INHABITANT
where name = 'Stranger'
Select * from INHABITANT
where name = 'Stranger'
Select personid	 from INHABITANT
where name = 'Stranger'
-- Hi Ernest! How much is a sword?
-- Hi Ernest! How much is a sword?
Select gold from INHABITANT
where name = 'Stranger'
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
Select gold from INHABITANT
where name = 'Stranger'
Select ITEM from Item where owner = NULL
Select ITEM from Item where owner = 'NULL'
Select item from Item where owner = 'NULL'
Select item from Item where owner is NULL
Select * from Item where owner is NULL
-- Yay, a coffee cup. Let's collect it!
-- Yay, a coffee cup. Let's collect it!
UPDATE item SET owner = 20 WHERE item = 'coffee cup'
-- Do you know a trick how to collect all the ownerless items?
UPDATE item SET owner = 20 WHERE item is NULL
UPDATE item SET owner = 20 WHERE item IS NULL
UPDATE item SET owner = 20 WHERE owner IS NULL
-- Now list all of the items I have!
-- Now list all of the items I have!
UPDATE item SET owner = 20 WHERE owner IS NULL
select item from ITEM where owner = 20
select * from ITEM where owner = 20
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
-- Find a friendly inhabitant who is either a dealer or a merchant. Maybe they want to buy some of my items. (Hint: When you use both AND and OR, don't forget to put brackets correctly!)
Select * FROM INHABITANT
Where state = 'friendly'
and
job = 'dealer'
Select * FROM INHABITANT
Where state = 'friendly'
and
job = 'dealer'
or
job = 'merchant'
-- I'd like to get the ring and the teapot. The rest is nothing but scrap. Please give me the two items. My personid is 15.
-- I'd like to get the ring and the teapot. The rest is nothing but scrap. Please give me the two items. My personid is 15.
Update item SET owner = 15 WHERE item = 'ring','ring'
Update item SET owner = 15 WHERE item = 'ring'and item = 'teapot'
Update item SET owner = 15 WHERE item = ('ring', 'teapot')
Update item SET owner = 15 WHERE item is like ('ring', 'teapot')
Update item SET owner = 15 WHERE item = ('ring', 'teapot')
Update item SET owner = 15 WHERE item = ('ring' or 'teapot')
Update item SET owner = 15 WHERE item = ('ring', 'teapot')
Update item SET owner = 15 WHERE (item = 'ring' or item ='teapot')
-- Here, some gold!
-- Here, some gold!
UPDATE inhabitant SET gold = gold + 120 WHERE personid = 20
-- Unfortunately, that's not enough gold to buy a sword. Seems like I do have to work after all. Maybe it's not a bad idea to change my name from Stranger to my real name before I will apply for a job.
update INHABITANT set name = 'Rob' WHERE personid = 20
-- Since baking is one of my hobbies, why not find a baker who I can work for? (Hint: List all bakers and use 'ORDER BY gold' to sort the results. 'ORDER BY gold DESC' is even better because then the richest baker is on top.)
-- Since baking is one of my hobbies, why not find a baker who I can work for? (Hint: List all bakers and use 'ORDER BY gold' to sort the results. 'ORDER BY gold DESC' is even better because then the richest baker is on top.)
Select * from INHABITANT where job = 'baker'
-- Hi, you again! So, Rob is your name. I saw you want to work as a baker? Okay! You will be paid 1 gold for 100 bread rolls.
-- Hi, you again! So, Rob is your name. I saw you want to work as a baker? Okay! You will be paid 1 gold for 100 bread rolls.
UPDATE inhabitant SET gold = gold + 100 - 150 WHERE personid = 20
-- Here's your new sword, Rob! Now you can go everywhere.
INSERT INTO item (item, owner) VALUES ('sword', 20)
-- Is there a pilot on this island by any chance? He could fly me home.
Select * from INHABITANT where job = 'pilot'
-- Horrible, the pilot is held captive by Dirty Dieter! I will show you a trick how to find out the name of the village where Dirty Dieter lives.
-- Horrible, the pilot is held captive by Dirty Dieter! I will show you a trick how to find out the name of the village where Dirty Dieter lives.
SELECT village.name FROM village, inhabitant WHERE village.villageid = inhabitant.villageid AND inhabitant.name = 'Dirty Dieter'
-- The expression presented here is called a join. It combines the information of the inhabitant table with information of the village table by matching villageid values.
SELECT cheif From VILLAGE where name = 'Onionville'
SELECT chief From VILLAGE where name = 'Onionville'
SELECT * From VILLAGE where name = 'Onionville'
SELECT village.name FROM village, inhabitant WHERE village.villageid = inhabitant.villageid AND VILLAGE .name = 'Onionville'
SELECT village.name FROM village, inhabitant WHERE village.villageid = inhabitant.villageid AND VILLAGE .name = 'Onionville' and INHABITANT.personid = 13
SELECT INHABITANT.name FROM village, inhabitant WHERE village.villageid = inhabitant.villageid AND VILLAGE .name = 'Onionville' and INHABITANT.personid = 13
-- Um, how many inhabitants does Onionville have?
-- Um, how many inhabitants does Onionville have?
SELECT COUNT(*) FROM inhabitant, village WHERE village.villageid = inhabitant.villageid AND village.name = 'Onionville'
-- Hello Rob, the pilot is held captive by Dirty Dieter in his sister's house. Shall I tell you how many women there are in Onionville? Nah, you can figure it out by yourself! (Hint: Women show up as gender = 'f')
SELECT INHABITANT.name FROM village, inhabitant WHERE village.villageid = inhabitant.villageid AND VILLAGE .name = 'Onionville' and INHABITANT.gender = 'f'
