-- Oh dear, what happened? It seems that I am the only survivor of the air crash. Wow, there are some villages on this island.
SELECT * FROM village
-- It seems there are a few people living in these villages. How can I see a list of all inhabitants?
SELECT * 
FROM village
SELECT * 
FROM inhabitant 
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
-- Man! I'm hungry. I will go and find a butcher to ask for some free sausages.
SELECT * FROM inhabitant WHERE job = 'butcher'
-- There you are! Enjoy your meal! But take care of yourself. As long as you are unarmed, stay away from villains. Not everyone on this island is friendly.
SELECT * 
FROM inhabitant 
WHERE state = 'friendly'
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
-- There is no way around getting a sword for myself. I will now try to find a friendly weaponsmith to forge me one. (Hint: You can combine predicates in the WHERE clause with AND)
SELECT * 
FROM inhabitant 
WHERE state = 'friendly'
AND job = 'weaponsmith'
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
-- Oh, that does not look good. Maybe other friendly smiths can help you out, e.g. a blacksmith. Try out: job LIKE '%smith' to find all inhabitants whose job ends with 'smith' (% is a wildcard for any number of characters).
SELECT * 
FROM inhabitant 
WHERE state = 'friendly'
AND job LIKE '%smith'
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
-- Hi stranger! Where are you going? I'm Paul, I'm the major of Monkeycity. I will go ahead and register you as a citizen.
INSERT INTO inhabitant (name, villageid, gender, job, gold, state) VALUES ('Stranger', 1, '?', '?', 0, '?')
-- No need to call me stranger! What's my personid? (Hint: In former queries, the * stands for: all columns. Instead of the star, you can also address one or more columns (seperated by a comma) and you will only get the columns you need.)
SELECT personid
FROM inhabitant 
WHERE name = 'stranger'

SELECT personid
FROM inhabitant 
WHERE name = 'Stranger'

-- Hi Ernest! How much is a sword?
-- Hi Ernest! How much is a sword?
SELECT gold
FROM inhabitant 
WHERE name = 'Stranger'

-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
-- Damn! No mon, no fun. There has to be another option to earn gold other than going to work. Maybe I could collect ownerless items and sell them! Can I make a list of all items that don't belong to anyone? (Hint: You can recognize ownerless items by: WHERE owner IS NULL)
SELECT *
FROM item 
WHERE owner IS NULL

-- Yay, a coffee cup. Let's collect it!
-- Yay, a coffee cup. Let's collect it!
UPDATE item SET owner = 20 WHERE item = 'coffee cup'
-- Do you know a trick how to collect all the ownerless items?
SELECT item
FROM item 
WHERE item IS 'coffee cup'


SELECT *
FROM item 
WHERE owner IS NULL


SELECT *
FROM item 
WHERE owner IS NULL

SELECT item
FROM item 
WHERE owner IS NULL

SELECT item.item
FROM item 
WHERE owner IS NULL

SELECT item
FROM item 
WHERE owner = NULL

SELECT item
FROM item 
WHERE owner like NULL

SELECT item
FROM item 
WHERE owner is NULL

SELECT item,owner
FROM item 
WHERE owner is NULL

SELECT item, gold
FROM item , inhabitant
WHERE owner, name  is NULL

